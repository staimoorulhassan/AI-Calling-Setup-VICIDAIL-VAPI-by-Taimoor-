# Technical Plan: AI Outbound Call Lead Generation System

## Feature ID: 001-ai-outbound-caller
## Spec Reference: spec.md
## Date: 2026-06-08

---

## 1. Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           BROWSER (Dashboard)                                │
│  React 19 + TypeScript + Tailwind + shadcn/ui + tRPC Client                 │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                           API SERVER (Hono + tRPC)                           │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐ ┌──────────────┐       │
│  │   Campaign   │ │    Call      │ │    Lead      │ │   Vicidial   │       │
│  │    Router    │ │   Router     │ │   Router     │ │   Router     │       │
│  └──────────────┘ └──────────────┘ └──────────────┘ └──────────────┘       │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐ ┌──────────────┐       │
│  │   AVR Agent  │ │   MOSS-TTS   │ │   Analytics  │ │   WebSocket  │       │
│  │   Router     │ │   Router     │ │   Router     │ │   Subs       │       │
│  └──────────────┘ └──────────────┘ └──────────────┘ └──────────────┘       │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                    ┌─────────────────┼─────────────────┐
                    ▼                 ▼                 ▼
           ┌──────────────┐  ┌──────────────┐  ┌──────────────────┐
           │   MySQL DB   │  │   MOSS-TTS   │  │    Vicidialer    │
           │  (Drizzle)   │  │   Service    │  │   (Asterisk)     │
           └──────────────┘  └──────────────┘  └──────────────────┘
                                               │
                                               ▼
                                      ┌──────────────────┐
                                      │   AVR Core       │
                                      │  (AudioSocket)   │
                                      └──────────────────┘
```

---

## 2. Technology Stack

### 2.1 Frontend
- **Framework**: React 19 + TypeScript + Vite
- **Styling**: Tailwind CSS 3.4 + shadcn/ui components
- **State Management**: tRPC React Query + Zustand for local state
- **Real-time**: tRPC WebSocket subscriptions for live call updates
- **Charts**: Recharts for analytics dashboards
- **Tables**: TanStack Table for call logs

### 2.2 Backend
- **Server**: Hono (HTTP framework)
- **API**: tRPC 11.x with Zod validation
- **Database**: MySQL 8.x with Drizzle ORM
- **Auth**: OAuth 2.0 (Kimi Auth) - optional for admin dashboard
- **WebSocket**: tRPC subscriptions for real-time events

### 2.3 Voice Integration
- **AVR Core**: Docker container with AudioSocket on port 5001
- **MOSS-TTS**: Custom adapter following avr-tts-* pattern
- **ASR**: Deepgram or Whisper via AVR ASR adapter
- **Audio Format**: 8kHz μ-law (ulaw) for telephony

### 2.4 Vicidialer Integration
- **AMI**: asterisk-manager library for call control
- **API**: HTTP requests to Vicidialer non-agent API
- **Transfer**: Asterisk Dial() with AudioSocket or Vicidial conferencer

---

## 3. Database Schema

### 3.1 Tables

```sql
-- Campaigns: AI campaign configuration linked to Vicidialer
CREATE TABLE campaigns (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  vicidial_campaign_id VARCHAR(50) NOT NULL,
  status ENUM('active','inactive','paused') DEFAULT 'inactive',
  greeting_message TEXT NOT NULL,
  closing_message TEXT,
  transfer_message TEXT,
  moss_voice_id VARCHAR(100) NOT NULL,
  language VARCHAR(10) DEFAULT 'en-US',
  tts_speed DECIMAL(3,2) DEFAULT 1.0,
  tts_pitch DECIMAL(3,2) DEFAULT 1.0,
  verifier_ingroup VARCHAR(100) NOT NULL,
  verifier_extension VARCHAR(50),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Qualifying Questions: 3 questions per campaign
CREATE TABLE qualifying_questions (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  campaign_id BIGINT UNSIGNED NOT NULL REFERENCES campaigns(id),
  question_order INT NOT NULL CHECK (question_order BETWEEN 1 AND 3),
  question_text TEXT NOT NULL,
  expected_answer_type ENUM('yes_no','numeric','text','choice') DEFAULT 'text',
  validation_rules JSON,
  is_required BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY (campaign_id, question_order)
);

-- Leads: Prospects to call
CREATE TABLE leads (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  phone_number VARCHAR(20) NOT NULL,
  first_name VARCHAR(100),
  last_name VARCHAR(100),
  email VARCHAR(255),
  vicidial_lead_id VARCHAR(50),
  list_id VARCHAR(50),
  campaign_id BIGINT UNSIGNED NOT NULL REFERENCES campaigns(id),
  status ENUM('new','dialed','connected','qualified','not_qualified','not_interested','dnc','converted') DEFAULT 'new',
  custom_fields JSON,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Call Sessions: Individual call tracking
CREATE TABLE call_sessions (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  lead_id BIGINT UNSIGNED NOT NULL REFERENCES leads(id),
  campaign_id BIGINT UNSIGNED NOT NULL REFERENCES campaigns(id),
  vicidial_call_id VARCHAR(100),
  call_status ENUM('initiated','connected','qualifying_q1','qualifying_q2','qualifying_q3','transferring','transferred','completed','failed','voicemail','busy','no_answer') DEFAULT 'initiated',
  verifier_id BIGINT UNSIGNED,
  started_at TIMESTAMP,
  connected_at TIMESTAMP,
  transferred_at TIMESTAMP,
  ended_at TIMESTAMP,
  duration_seconds INT,
  transfer_success BOOLEAN DEFAULT false,
  recording_url VARCHAR(500),
  hangup_cause VARCHAR(50),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Question Answers: Transcribed answers
CREATE TABLE question_answers (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  call_session_id BIGINT UNSIGNED NOT NULL REFERENCES call_sessions(id),
  question_id BIGINT UNSIGNED NOT NULL REFERENCES qualifying_questions(id),
  question_text TEXT NOT NULL,
  transcribed_answer TEXT,
  confidence_score DECIMAL(5,4),
  answered_at TIMESTAMP,
  is_valid BOOLEAN DEFAULT true
);

-- Call Logs: Detailed event log
CREATE TABLE call_logs (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  call_session_id BIGINT UNSIGNED NOT NULL REFERENCES call_sessions(id),
  event_type ENUM('dial','connect','tts_greeting','ask_q1','listen_q1','ask_q2','listen_q2','ask_q3','listen_q3','announce_transfer','initiate_3way','bridge_confirmed','ai_dropoff','verifier_join','hangup','error') NOT NULL,
  event_data JSON,
  moss_audio_url VARCHAR(500),
  timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Verifiers: Human verifier agents
CREATE TABLE verifiers (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  vicidial_user_id VARCHAR(50),
  extension VARCHAR(50),
  status ENUM('online','offline','busy') DEFAULT 'offline',
  max_concurrent_calls INT DEFAULT 1,
  current_calls INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

---

## 4. API Design (tRPC Routers)

### 4.1 Campaign Router (`api/routers/campaign.ts`)
```
campaign.list          - query: List all campaigns with filters
campaign.getById       - query: Get campaign by ID with questions
campaign.create        - mutation: Create campaign + 3 questions
campaign.update        - mutation: Update campaign settings
campaign.delete        - mutation: Soft delete campaign
campaign.syncVicidial  - mutation: Sync campaigns from Vicidialer
campaign.getStats      - query: Get campaign statistics
```

### 4.2 Call Router (`api/routers/call.ts`)
```
call.list              - query: List call sessions with filters
call.getById           - query: Get call session with answers and logs
call.getActive         - query: Get currently active calls
call.subscribeActive   - subscription: Real-time active call updates
call.getStats          - query: Call statistics by date range
call.updateStatus      - mutation: Update call status
call.handleWebhook     - mutation: Receive Vicidialer/AVR webhooks
```

### 4.3 Lead Router (`api/routers/lead.ts`)
```
lead.list              - query: List leads with filters
lead.getById           - query: Get lead by ID
lead.import            - mutation: Import leads from Vicidialer
lead.updateStatus      - mutation: Update lead status
lead.getStats          - query: Lead statistics
```

### 4.4 AVR Agent Router (`api/routers/avr-agent.ts`)
```
avrAgent.getConfig     - query: Get AVR config for campaign
tts.synthesize         - mutation: Convert text to speech via MOSS-TTS
tts.getVoices          - query: List available MOSS-TTS voices
asr.getTranscription   - subscription: Real-time transcription stream
call.handleEvent       - mutation: Process AVR call events
```

### 4.5 Vicidial Router (`api/routers/vicidial.ts`)
```
vicidial.getCampaigns  - query: Fetch Vicidialer campaigns
vicidial.getLists      - query: Fetch lead lists
vicidial.transferCall  - mutation: Initiate 3-way transfer
vicidial.setDisposition- mutation: Set call disposition
vicidial.getAgents     - query: Get available verifier agents
```

### 4.6 Analytics Router (`api/routers/analytics.ts`)
```
analytics.getDashboard    - query: Dashboard summary metrics
analytics.getFunnel       - query: Conversion funnel data
analytics.getCampaignPerf - query: Campaign performance comparison
analytics.getVerifierPerf - query: Verifier performance metrics
analytics.exportCalls     - mutation: Export call data CSV
```

---

## 5. Component Architecture

### 5.1 Pages
```
/src/pages/
├── Dashboard.tsx          # Main dashboard with KPI cards + active calls
├── Campaigns.tsx          # Campaign list with create/edit
├── CampaignForm.tsx       # Campaign creation/editing form
├── Calls.tsx              # Call history with filters
├── CallDetail.tsx         # Single call detail view
├── Leads.tsx              # Lead management
├── Analytics.tsx          # Reports and charts
├── Settings.tsx           # System settings (Vicidial, AVR, MOSS config)
└── Login.tsx              # Auth page
```

### 5.2 Key Components
```
/src/components/
├── ActiveCallsTable.tsx   # Real-time active calls table
├── CallFunnelChart.tsx    # Conversion funnel visualization
├── CampaignCard.tsx       # Campaign summary card
├── QuestionBuilder.tsx    # 3-question builder form
├── TTSVoicePreview.tsx    # MOSS-TTS voice preview player
├── CallTimeline.tsx       # Call event timeline
├── StatsCards.tsx         # KPI stat cards
├── StatusBadge.tsx        # Call status badge component
└── RealtimeIndicator.tsx  # Live/real-time indicator dot
```

---

## 6. Call State Machine

```
                    ┌─────────────┐
                    │  INITIATED  │◄── Vicidialer dials
                    └──────┬──────┘
                           │ Connected
                           ▼
                    ┌─────────────┐
                    │  CONNECTED  │◄── AVR bridges
                    └──────┬──────┘
                           │ TTS Greeting
                           ▼
                 ┌─────────────────────┐
                 │    QUALIFYING_Q1    │◄── Ask Question 1
                 └──────────┬──────────┘
                            │ Answer Received
                            ▼
                 ┌─────────────────────┐
                 │    QUALIFYING_Q2    │◄── Ask Question 2
                 └──────────┬──────────┘
                            │ Answer Received
                            ▼
                 ┌─────────────────────┐
                 │    QUALIFYING_Q3    │◄── Ask Question 3
                 └──────────┬──────────┘
                            │ Answer Received
                            ▼
                    ┌─────────────┐
                    │ TRANSFERRING │◄── Initiate 3-way
                    └──────┬──────┘
                           │ Bridge Confirmed
                           ▼
                    ┌─────────────┐
                    │ TRANSFERRED  │◄── Verifier connected
                    └──────┬──────┘
                           │ Verifier ends
                           ▼
                    ┌─────────────┐
                    │  COMPLETED  │
                    └─────────────┘

    Error Paths:
    - Any state ──► FAILED (on error)
    - INITIATED ──► BUSY / NO_ANSWER / VOICEMAIL
    - TRANSFERRING ──► COMPLETED (fallback on transfer fail)
```

---

## 7. External Service Integration Details

### 7.1 Vicidialer API
- **Base URL**: Configured per installation (e.g., http://vicidial-server/vicidial/)
- **Auth**: API key + user credentials
- **Endpoints**:
  - GET /non_agent_api.php?function=campaigns
  - GET /non_agent_api.php?function=leads&list_id=X
  - POST /non_agent_api.php?function=update_lead
  - POST /non_agent_api.php?function=transfer_conference

### 7.2 Asterisk AMI
- **Connection**: TCP to port 5038
- **Actions**: Originate, Bridge, Redirect, Monitor
- **Events**: Newchannel, Hangup, Bridge, Dial
- **Transfer**: Action: Originate -> Channel: Local/XXX -> Context: from-internal -> Exten: YYY

### 7.3 AVR AudioSocket
- **Protocol**: Custom TCP binary protocol
- **Port**: 5001 (per AVR config)
- **Message Types**: S (Start), H (Hangup), D (Data)
- **Audio**: 8kHz μ-law, 320 bytes per packet (20ms)
- **Integration**: AVR Core routes to our webhook endpoint

### 7.4 MOSS-TTS
- **Endpoint**: http://moss-tts:8080/synthesize (configurable)
- **Input**: JSON { text, voice_id, speed, pitch, language }
- **Output**: Audio stream (convert to ulaw for AVR)
- **Adapter Pattern**: Following avr-tts-* repository structure

---

## 8. Real-Time Architecture

### 8.1 WebSocket Subscriptions
- **call.subscribeActive**: Pushes active call updates every 3 seconds
- **asr.getTranscription**: Streams transcription in real-time
- **dashboard.subscribeMetrics**: Pushes dashboard KPI updates

### 8.2 Event Flow
```
Vicidialer Dial ──► AMI Event ──► Webhook ──► API ──► DB ──► WS Push ──► Dashboard
AVR Greeting ──► Webhook ──► API ──► DB ──► WS Push ──► Dashboard
Lead Answers ──► ASR ──► AVR ──► Webhook ──► API ──► DB ──► WS Push
Transfer Init ──► AMI ──► Webhook ──► API ──► DB ──► WS Push
Transfer Done ──► AMI ──► Webhook ──► API ──► DB ──► WS Push
```

---

## 9. Deployment

### 9.1 Docker Services
```yaml
services:
  app:              # Full-stack app (Hono + React)
  mysql:            # MySQL 8 database
  avr-core:         # AVR Core with AudioSocket
  avr-asr:          # ASR adapter (Deepgram/Whisper)
  moss-tts:         # MOSS-TTS inference server
  vicidial-sync:    # Vicidialer sync worker
```

### 9.2 Environment Variables
```env
# Database
DATABASE_URL=mysql://user:pass@mysql:3306/ai_caller

# Vicidialer
VICIDIAL_URL=http://vicidial-server/vicidial
VICIDIAL_API_KEY=xxx
VICIDIAL_USER=admin

# Asterisk AMI
AMI_HOST=asterisk-server
AMI_PORT=5038
AMI_USERNAME=admin
AMI_SECRET=amp111

# AVR
AVR_CORE_URL=http://avr-core:5000
AVR_AUDIO_SOCKET_PORT=5001
AVR_WEBHOOK_URL=https://app/api/call/webhook

# MOSS-TTS
MOSS_TTS_URL=http://moss-tts:8080
MOSS_TTS_DEFAULT_VOICE=en-US-female-1

# App
PORT=3000
NODE_ENV=production
```

---

## 10. Implementation Order

1. **Phase 1**: Database schema + tRPC routers + seed data
2. **Phase 2**: Frontend pages + components + dashboard
3. **Phase 3**: Vicidialer API integration + sync
4. **Phase 4**: AVR integration + call state machine
5. **Phase 5**: MOSS-TTS adapter + TTS service
6. **Phase 6**: 3-way transfer + verifier bridge
7. **Phase 7**: Real-time WebSocket + live dashboard
8. **Phase 8**: Analytics + reporting + export
