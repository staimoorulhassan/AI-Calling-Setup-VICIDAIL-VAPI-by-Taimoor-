# Specification: AI Outbound Call Lead Generation System

## Feature ID: 001-ai-outbound-caller
## Status: Specified
## Date: 2026-06-08

---

## 1. Overview

An AI-powered outbound call system for lead generation that integrates with existing Vicidialer campaigns. When Vicidialer connects with a human lead, the call is transferred to an AI voice agent that asks 3 qualifying questions. Based on the answers, the AI initiates a 3-way transfer to a human verifier, then disconnects, leaving the verifier to close the lead.

### User Journeys

**Journey 1: Campaign Manager**
- Logs into dashboard
- Creates/Configures an AI-powered outbound campaign
- Sets the 3 qualifying questions
- Selects MOSS-TTS voice profile
- Monitors active calls in real-time
- Reviews call logs and conversion analytics

**Journey 2: Lead (Callee)**
- Receives outbound call from Vicidialer
- Hears AI agent greeting with MOSS-TTS synthesized voice
- Answers 3 qualifying questions naturally
- Gets transferred to human verifier seamlessly

**Journey 3: Verifier Agent**
- Receives 3-way transfer from AI with context
- Sees lead info and answered questions on screen
- Closes the qualified lead
- Sets disposition in Vicidialer

**Journey 4: AI Agent (System)**
- Receives call via AVR AudioSocket from Vicidialer
- Greets lead using MOSS-TTS
- Asks Question 1 -> Listens -> Acknowledges
- Asks Question 2 -> Listens -> Acknowledges
- Asks Question 3 -> Listens -> Acknowledges
- Initiates 3-way transfer to verifier queue
- Disconnects self after successful bridge

---

## 2. Functional Requirements

### 2.1 Campaign Management

- **FR-CM-01**: Create AI outbound campaigns linked to Vicidialer campaigns
- **FR-CM-02**: Configure 3 qualifying questions per campaign (text, expected type, validation rules)
- **FR-CM-03**: Map campaign to Vicidialer campaign_id, list_id, and user_group
- **FR-CM-04**: Set MOSS-TTS voice profile (voice_id, speed, pitch, language)
- **FR-CM-05**: Configure greeting message and closing message before transfer
- **FR-CM-06**: Set verifier queue/ingroup for 3-way transfers
- **FR-CM-07**: Activate/Deactivate campaigns

### 2.2 Call Orchestration

- **FR-CO-01**: Receive call events from Vicidialer via AMI/webhook
- **FR-CO-02**: Bridge connected calls to AVR AudioSocket extension
- **FR-CO-03**: AI agent greets lead with configured greeting + MOSS-TTS
- **FR-CO-04**: AI asks Question 1, captures answer via ASR, validates
- **FR-CO-05**: AI asks Question 2, captures answer via ASR, validates
- **FR-CO-06**: AI asks Question 3, captures answer via ASR, validates
- **FR-CO-07**: AI announces pending transfer to verifier
- **FR-CO-08**: Initiate 3-way conference call to verifier ingroup
- **FR-CO-09**: AI drops off after successful bridge confirmation
- **FR-CO-10**: Handle hangup, busy, no-answer, voicemail detection
- **FR-CO-11**: Handle transfer failure - retry once, then provide fallback message

### 2.3 MOSS-TTS Integration

- **FR-TTS-01**: Text-to-speech conversion via MOSS-TTS model
- **FR-TTS-02**: Streaming audio delivery to AVR AudioSocket
- **FR-TTS-03**: Voice profile selection per campaign
- **FR-TTS-04**: Support for English, Spanish, and Hindi languages
- **FR-TTS-05**: Audio format: 8kHz μ-law (ulaw) for telephony compatibility

### 2.4 ASR (Speech Recognition)

- **FR-ASR-01**: Real-time speech-to-text during call
- **FR-ASR-02**: Support for interruption (barge-in) detection
- **FR-ASR-03**: Noise filtering for telephony audio quality
- **FR-ASR-04**: Language matching campaign configuration

### 2.5 3-Way Transfer

- **FR-3W-01**: Dial verifier extension/ingroup via Asterisk
- **FR-3W-02**: Bridge lead and verifier with whisper announcement
- **FR-3W-03**: Confirm bridge before AI disconnect
- **FR-3W-04**: Pass lead context (answers, lead_id) to verifier screen
- **FR-3W-05**: Fallback on no verifier available (queue callback or voicemail)

### 2.6 Call Logging & Analytics

- **FR-CL-01**: Log every call with: lead_id, campaign_id, timestamps, duration, status
- **FR-CL-02**: Store all 3 questions and transcribed answers
- **FR-CL-03**: Record AI agent actions (greet, ask, listen, transfer, drop)
- **FR-CL-04**: Record verifier disposition and outcome
- **FR-AN-01**: Dashboard: Calls dialed, connected, qualified, transferred, converted
- **FR-AN-02**: Dashboard: Campaign performance comparison
- **FR-AN-03**: Dashboard: Real-time active calls monitor
- **FR-AN-04**: Export call logs and analytics CSV

### 2.7 Vicidialer Integration

- **FR-VD-01**: Sync campaigns from Vicidialer API
- **FR-VD-02**: Pull lead lists for dialing
- **FR-VD-03**: Push call dispositions back to Vicidialer
- **FR-VD-04**: Agent login/logout via Vicidialer API
- **FR-VD-05**: 3-way transfer using Vicidialer's conferencer or Asterisk AMI

---

## 3. Non-Functional Requirements

- **NFR-01**: Call latency: AI response within 800ms of user speech end
- **NFR-02**: TTS latency: First audio byte within 500ms of text generation
- **NFR-03**: System supports 50 concurrent AI calls minimum
- **NFR-04**: 99.9% uptime for call orchestration service
- **NFR-05**: All call data encrypted at rest and in transit
- **NFR-06**: Dashboard loads in under 2 seconds
- **NFR-07**: Real-time call events delivered within 500ms

---

## 4. Data Model

### 4.1 Core Entities

**Campaign**
- id, name, vicidial_campaign_id, status (active/inactive)
- greeting_message, closing_message, transfer_message
- moss_voice_id, language, tts_speed, tts_pitch
- verifier_ingroup, verifier_extension
- created_at, updated_at

**QualifyingQuestion**
- id, campaign_id, order (1-3), question_text
- expected_answer_type (yes_no/numeric/text/choice)
- validation_rules (JSON), is_required
- created_at

**Lead**
- id, phone_number, first_name, last_name, email
- vicidial_lead_id, list_id, campaign_id
- status (new/dialed/connected/qualified/not_interested/dnc)
- custom_fields (JSON), created_at, updated_at

**CallSession**
- id, lead_id, campaign_id, vicidial_call_id
- call_status (initiated/connected/qualifying/transferred/completed/failed)
- started_at, connected_at, transferred_at, ended_at
- duration_seconds, transfer_success
- recording_url, hangup_cause

**QuestionAnswer**
- id, call_session_id, question_id, question_text
- transcribed_answer, confidence_score
- answered_at, validated (boolean)

**CallLog**
- id, call_session_id, event_type, event_data (JSON)
- timestamp, moss_audio_url

**Verifier**
- id, name, vicidial_user_id, extension
- status (online/offline/busy), max_concurrent_calls
- created_at

### 4.2 Entity Relationships

```
Campaign 1--* QualifyingQuestion
Campaign 1--* Lead
Campaign 1--* CallSession
Lead 1--* CallSession
CallSession 1--* QuestionAnswer
CallSession 1--* CallLog
CallSession *--1 Verifier (transferred_to)
```

---

## 5. User Stories

### US-001: Campaign Manager Creates Campaign
As a campaign manager, I want to create a new AI outbound campaign linked to my Vicidialer campaign, so that AI agents can start qualifying leads.

**Acceptance Criteria:**
- Can select from synced Vicidialer campaigns
- Can enter 3 qualifying questions with validation rules
- Can select MOSS-TTS voice from available profiles
- Can preview TTS voice with sample text
- Campaign saves with active status

### US-002: Lead Receives AI Call
As a lead, when I answer an outbound call, I want to hear a natural-sounding AI agent ask me relevant questions, so I can quickly qualify for the service.

**Acceptance Criteria:**
- Greeting plays within 2 seconds of answer
- AI voice sounds natural and clear (MOSS-TTS)
- Questions are asked one at a time
- AI acknowledges my answers before next question
- Transfer to human is smooth with context

### US-003: Verifier Receives Qualified Lead
As a verifier, I want to receive transferred calls with the lead's already-answered questions visible, so I can efficiently close qualified leads.

**Acceptance Criteria:**
- 3-way transfer connects within 5 seconds
- Verifier screen shows lead info + 3 answers
- Call recording starts automatically
- Can set disposition that syncs back to Vicidialer

### US-004: Manager Monitors Real-Time Calls
As a campaign manager, I want to see all active AI calls in real-time, so I can monitor performance and intervene if needed.

**Acceptance Criteria:**
- Dashboard shows active calls with status
- Each call shows: lead phone, campaign, current step, duration
- Auto-refreshes every 3 seconds
- Can click into call for detailed view

### US-005: Manager Reviews Analytics
As a campaign manager, I want to view campaign analytics, so I can optimize AI questions and verifier performance.

**Acceptance Criteria:**
- Date range filter on all reports
- Conversion funnel: Dialed -> Connected -> Qualified -> Transferred -> Closed
- Question-level analytics (answer distribution)
- Verifier performance comparison
- Export to CSV

---

## 6. Integration Points

### 6.1 Vicidialer Integration
- **API**: Vicidialer non-agent API for campaign/lead sync
- **AMI**: Asterisk Manager Interface for call control
- **Webhooks**: Call event notifications (dial, answer, hangup)
- **Transfer**: 3-way via Asterisk Dial() or Vicidial conferencer

### 6.2 AVR Integration
- **AudioSocket**: AVR Core receives/sends audio via TCP socket
- **Format**: 8kHz μ-law, 16-bit PCM
- **Extensions**: AVR dialplan extensions per campaign
- **Events**: Webhook callbacks for call lifecycle

### 6.3 MOSS-TTS Integration
- **API**: Local/remote MOSS-TTS inference endpoint
- **Input**: Text + voice parameters
- **Output**: Raw audio stream (converted to ulaw)
- **Streaming**: Chunked delivery to AVR

### 6.4 ASR Integration
- **Provider**: Whisper/Deepgram/Vosk via AVR ASR adapter
- **Streaming**: Real-time transcription via WebSocket
- **Language**: Per-campaign configuration
