# AI Outbound Caller - Project Constitution

## Core Principles

1. **Spec-Driven Development**: All features start with a specification, followed by a technical plan, then implementation tasks. No code without specs.

2. **Integration-First Architecture**: This system integrates with existing Vicidialer campaigns and AVR (Agent Voice Response) infrastructure. We build adapters, not replacements.

3. **Call Flow is Sacred**: The 5-step call flow (Dial -> Connect -> AI Qualify -> 3-Way Transfer -> Verifier Close) must never break. Every component design prioritizes call continuity.

4. **Modular AI Components**: Following AVR's architecture, ASR, LLM, and TTS are swappable modules. MOSS-TTS is our primary TTS engine.

5. **Observable & Auditable**: Every call, every question, every answer, every transfer is logged. Dashboard provides real-time visibility.

## Technical Standards

- **Backend**: tRPC + Drizzle ORM + Hono + MySQL
- **Frontend**: React 19 + TypeScript + Tailwind CSS + shadcn/ui
- **Voice**: AVR Core via AudioSocket, MOSS-TTS adapter
- **Telephony**: Vicidialer API + Asterisk AMI
- **Type Safety**: End-to-end TypeScript, Zod validation on all APIs
- **Error Handling**: Every external API call (Vicidial, AVR, MOSS) has retry logic and graceful degradation

## Call Flow Specification (Non-Negotiable)

```
Step 1: Vicidialer dials lead (predictive/broadcast/manual)
Step 2: Human answers -> Vicidialer bridges to AVR AudioSocket extension
Step 3: AI Agent greets lead, asks 3 qualifying questions sequentially
Step 4: After 3rd answer, AI initiates 3-way conference with verifier human
Step 5: AI drops off, verifier continues, Vicidialer logs disposition
```

## Quality Gates

- All database queries use Drizzle ORM (no raw SQL)
- All API inputs validated with Zod schemas
- All external service calls have timeout and retry
- Call state machine must handle: hangup, no-answer, busy, machine-detection, transfer-failure
- Dashboard updates in real-time via tRPC subscriptions
