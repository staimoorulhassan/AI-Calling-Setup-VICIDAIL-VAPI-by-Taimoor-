import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router";
import { trpc } from "@/providers/trpc";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { ArrowLeft, Volume2 } from "lucide-react";

const answerTypes = [
  { value: "yes_no", label: "Yes / No" },
  { value: "numeric", label: "Numeric (Amount, Count)" },
  { value: "text", label: "Free Text" },
  { value: "choice", label: "Multiple Choice" },
];

const languages = [
  { value: "en-US", label: "English (US)" },
  { value: "es-ES", label: "Spanish" },
  { value: "hi-IN", label: "Hindi" },
];

export default function CampaignForm() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isEdit = Boolean(id);
  const utils = trpc.useUtils();

  const { data: existingCampaign } = trpc.campaign.getById.useQuery(
    { id: Number(id) },
    { enabled: isEdit }
  );
  const { data: voices } = trpc.avr.getVoices.useQuery();
  const { data: vdCampaigns } = trpc.vicidial.getCampaigns.useQuery();

  const createMutation = trpc.campaign.create.useMutation({
    onSuccess: () => {
      utils.campaign.list.invalidate();
      toast.success("Campaign created successfully");
      navigate("/campaigns");
    },
    onError: (err) => toast.error(err.message),
  });

  const updateMutation = trpc.campaign.update.useMutation({
    onSuccess: () => {
      utils.campaign.list.invalidate();
      toast.success("Campaign updated successfully");
      navigate("/campaigns");
    },
    onError: (err) => toast.error(err.message),
  });

  const [form, setForm] = useState({
    name: "",
    vicidialCampaignId: "",
    greetingMessage: "",
    closingMessage: "",
    transferMessage: "",
    mossVoiceId: "",
    language: "en-US",
    ttsSpeed: "1.00",
    ttsPitch: "1.00",
    verifierIngroup: "",
    verifierExtension: "",
  });

  const [questions, setQuestions] = useState<
    { questionText: string; expectedAnswerType: "yes_no" | "numeric" | "text" | "choice"; validationRules: any; isRequired: boolean }[]
  >([
    { questionText: "", expectedAnswerType: "text", validationRules: null, isRequired: true },
    { questionText: "", expectedAnswerType: "text", validationRules: null, isRequired: true },
    { questionText: "", expectedAnswerType: "text", validationRules: null, isRequired: true },
  ]);

  useEffect(() => {
    if (existingCampaign) {
      setForm({
        name: existingCampaign.name,
        vicidialCampaignId: existingCampaign.vicidialCampaignId,
        greetingMessage: existingCampaign.greetingMessage,
        closingMessage: existingCampaign.closingMessage || "",
        transferMessage: existingCampaign.transferMessage || "",
        mossVoiceId: existingCampaign.mossVoiceId,
        language: existingCampaign.language,
        ttsSpeed: String(existingCampaign.ttsSpeed),
        ttsPitch: String(existingCampaign.ttsPitch),
        verifierIngroup: existingCampaign.verifierIngroup,
        verifierExtension: existingCampaign.verifierExtension || "",
      });
      if (existingCampaign.questions) {
        setQuestions(
          existingCampaign.questions.map((q: any) => ({
            questionText: q.questionText,
            expectedAnswerType: q.expectedAnswerType,
            validationRules: q.validationRules,
            isRequired: q.isRequired,
          }))
        );
      }
    }
  }, [existingCampaign]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.vicidialCampaignId || !form.greetingMessage || !form.mossVoiceId || !form.verifierIngroup) {
      toast.error("Please fill in all required fields");
      return;
    }
    if (questions.some((q) => !q.questionText)) {
      toast.error("All 3 qualifying questions are required");
      return;
    }

    const payload = {
      ...form,
      questions: questions.map((q) => ({
        ...q,
        validationRules: q.validationRules || undefined,
      })),
    };

    if (isEdit) {
      updateMutation.mutate({ id: Number(id), ...payload });
    } else {
      createMutation.mutate(payload);
    }
  };

  const updateQuestion = (index: number, field: string, value: string | boolean | any) => {
    const updated = [...questions];
    updated[index] = { ...updated[index], [field]: value };
    setQuestions(updated);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={() => navigate("/campaigns")}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold tracking-tight">
            {isEdit ? "Edit Campaign" : "New Campaign"}
          </h1>
          <p className="text-sm text-muted-foreground">
            Configure your AI outbound campaign with 3 qualifying questions
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Basic Info */}
        <Card>
          <CardHeader>
            <CardTitle>Campaign Details</CardTitle>
            <CardDescription>Link to your Vicidialer campaign and configure basic settings</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Campaign Name *</Label>
                <Input
                  id="name"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="e.g., Home Insurance Q2 2026"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="vdCampaign">Vicidial Campaign *</Label>
                <Select
                  value={form.vicidialCampaignId}
                  onValueChange={(v) => setForm({ ...form, vicidialCampaignId: v })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select Vicidial campaign" />
                  </SelectTrigger>
                  <SelectContent>
                    {Array.isArray(vdCampaigns) &&
                      vdCampaigns.map((c: any) => (
                        <SelectItem key={c.campaignId || c.campaign_id} value={c.campaignId || c.campaign_id}>
                          {c.campaignName || c.campaign_name}
                        </SelectItem>
                      ))}
                    {!Array.isArray(vdCampaigns) && (
                      <SelectItem value="DEMO-1">Demo Outbound Campaign 1</SelectItem>
                    )}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="greeting">AI Greeting Message *</Label>
              <Textarea
                id="greeting"
                value={form.greetingMessage}
                onChange={(e) => setForm({ ...form, greetingMessage: e.target.value })}
                placeholder="Hello! This is an important call about..."
                rows={3}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="closing">Closing / Transfer Message</Label>
              <Textarea
                id="closing"
                value={form.closingMessage}
                onChange={(e) => setForm({ ...form, closingMessage: e.target.value })}
                placeholder="Thank you! I'm now connecting you with a specialist..."
                rows={2}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="verifierIngroup">Verifier Ingroup *</Label>
                <Input
                  id="verifierIngroup"
                  value={form.verifierIngroup}
                  onChange={(e) => setForm({ ...form, verifierIngroup: e.target.value })}
                  placeholder="e.g., INSURANCE-VERIFIERS"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="verifierExt">Verifier Extension</Label>
                <Input
                  id="verifierExt"
                  value={form.verifierExtension}
                  onChange={(e) => setForm({ ...form, verifierExtension: e.target.value })}
                  placeholder="e.g., 8801"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Voice Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Volume2 className="h-5 w-5" />
              Voice Settings (MOSS-TTS)
            </CardTitle>
            <CardDescription>Configure the AI agent voice using MOSS-TTS</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="voice">MOSS Voice *</Label>
                <Select value={form.mossVoiceId} onValueChange={(v) => setForm({ ...form, mossVoiceId: v })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select voice" />
                  </SelectTrigger>
                  <SelectContent>
                    {voices?.map((voice: any) => (
                      <SelectItem key={voice.id || voice.voice_id} value={voice.id || voice.voice_id}>
                        {voice.name || voice.id} ({voice.language})
                      </SelectItem>
                    )) || (
                      <>
                        <SelectItem value="en-US-female-1">English US Female</SelectItem>
                        <SelectItem value="en-US-male-1">English US Male</SelectItem>
                      </>
                    )}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="language">Language</Label>
                <Select value={form.language} onValueChange={(v) => setForm({ ...form, language: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {languages.map((l) => (
                      <SelectItem key={l.value} value={l.value}>
                        {l.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="speed">TTS Speed</Label>
                <Input
                  id="speed"
                  type="number"
                  step="0.1"
                  min="0.5"
                  max="2"
                  value={form.ttsSpeed}
                  onChange={(e) => setForm({ ...form, ttsSpeed: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="pitch">TTS Pitch</Label>
                <Input
                  id="pitch"
                  type="number"
                  step="0.1"
                  min="0.5"
                  max="2"
                  value={form.ttsPitch}
                  onChange={(e) => setForm({ ...form, ttsPitch: e.target.value })}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 3 Qualifying Questions */}
        <Card>
          <CardHeader>
            <CardTitle>3 Qualifying Questions</CardTitle>
            <CardDescription>
              The AI agent will ask these questions in sequence after the greeting
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {questions.map((q, idx) => (
              <div key={idx} className="p-4 rounded-lg border bg-muted/30 space-y-3">
                <div className="flex items-center gap-2">
                  <div className="h-6 w-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold">
                    {idx + 1}
                  </div>
                  <h4 className="font-medium">Question {idx + 1}</h4>
                </div>

                <div className="space-y-2">
                  <Label>Question Text *</Label>
                  <Textarea
                    value={q.questionText}
                    onChange={(e) => updateQuestion(idx, "questionText", e.target.value)}
                    placeholder={`e.g., ${idx === 0 ? "Do you own or rent your home?" : idx === 1 ? "How much do you pay for insurance monthly?" : "Would you like a personalized quote?"}`}
                    rows={2}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Expected Answer Type</Label>
                  <Select
                    value={q.expectedAnswerType}
                    onValueChange={(v) => updateQuestion(idx, "expectedAnswerType", v)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {answerTypes.map((t) => (
                        <SelectItem key={t.value} value={t.value}>
                          {t.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <div className="flex justify-end gap-3">
          <Button type="button" variant="outline" onClick={() => navigate("/campaigns")}>
            Cancel
          </Button>
          <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending}>
            {createMutation.isPending || updateMutation.isPending
              ? "Saving..."
              : isEdit
              ? "Update Campaign"
              : "Create Campaign"}
          </Button>
        </div>
      </form>
    </div>
  );
}
