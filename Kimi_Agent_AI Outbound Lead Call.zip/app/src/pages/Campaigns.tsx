import { Link } from "react-router";
import { trpc } from "@/providers/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Megaphone,
  Plus,
  Phone,
  PhoneForwarded,
  Pencil,
  Pause,
  Play,
  Globe,
  Volume2,
} from "lucide-react";
import { toast } from "sonner";

function StatusBadge({ status }: { status: string }) {
  const variants: Record<string, string> = {
    active: "bg-green-100 text-green-800 hover:bg-green-100",
    inactive: "bg-gray-100 text-gray-800 hover:bg-gray-100",
    paused: "bg-yellow-100 text-yellow-800 hover:bg-yellow-100",
  };
  return (
    <Badge variant="outline" className={variants[status] || ""}>
      {status.toUpperCase()}
    </Badge>
  );
}

export default function Campaigns() {
  const utils = trpc.useUtils();
  const { data: campaigns, isLoading } = trpc.campaign.list.useQuery({});
  const updateMutation = trpc.campaign.update.useMutation({
    onSuccess: () => {
      utils.campaign.list.invalidate();
      toast.success("Campaign updated");
    },
  });

  const toggleStatus = (id: number, current: string) => {
    const next = current === "active" ? "paused" : "active";
    updateMutation.mutate({ id, status: next as any });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Campaigns</h1>
          <p className="text-sm text-muted-foreground">
            Manage AI-powered outbound call campaigns
          </p>
        </div>
        <Link to="/campaigns/new">
          <Button className="gap-2">
            <Plus className="h-4 w-4" />
            New Campaign
          </Button>
        </Link>
      </div>

      {isLoading ? (
        <div className="text-center py-12 text-muted-foreground">Loading campaigns...</div>
      ) : !campaigns || campaigns.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16">
            <Megaphone className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">No campaigns yet</h3>
            <p className="text-sm text-muted-foreground mb-4 max-w-md text-center">
              Create your first AI outbound campaign linked to Vicidialer. Each campaign can have 3 qualifying questions.
            </p>
            <Link to="/campaigns/new">
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                Create Campaign
              </Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {campaigns.map((campaign) => (
            <Card key={campaign.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <CardTitle className="text-lg truncate pr-2">{campaign.name}</CardTitle>
                  <StatusBadge status={campaign.status} />
                </div>
                <div className="flex items-center gap-3 text-xs text-muted-foreground mt-1">
                  <span className="flex items-center gap-1">
                    <Globe className="h-3 w-3" />
                    {campaign.language}
                  </span>
                  <span className="flex items-center gap-1">
                    <Volume2 className="h-3 w-3" />
                    {campaign.mossVoiceId}
                  </span>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-3 gap-2">
                  <div className="text-center p-2 rounded bg-muted">
                    <Phone className="h-4 w-4 mx-auto mb-1 text-muted-foreground" />
                    <div className="text-lg font-semibold">{campaign.totalCalls}</div>
                    <div className="text-[10px] text-muted-foreground">Calls</div>
                  </div>
                  <div className="text-center p-2 rounded bg-muted">
                    <PhoneForwarded className="h-4 w-4 mx-auto mb-1 text-muted-foreground" />
                    <div className="text-lg font-semibold">{campaign.transferredCalls}</div>
                    <div className="text-[10px] text-muted-foreground">Xfer</div>
                  </div>
                  <div className="text-center p-2 rounded bg-muted">
                    <div className="text-lg font-semibold">
                      {campaign.totalCalls > 0
                        ? Math.round((campaign.transferredCalls / campaign.totalCalls) * 100)
                        : 0}
                      %
                    </div>
                    <div className="text-[10px] text-muted-foreground">Rate</div>
                  </div>
                </div>

                <div className="text-xs text-muted-foreground">
                  <p>
                    Vicidial: <span className="font-medium">{campaign.vicidialCampaignId}</span>
                  </p>
                  <p>
                    Verifier: <span className="font-medium">{campaign.verifierIngroup}</span>
                  </p>
                </div>

                <div className="flex gap-2">
                  <Link to={`/campaigns/${campaign.id}/edit`} className="flex-1">
                    <Button variant="outline" size="sm" className="w-full gap-1">
                      <Pencil className="h-3 w-3" />
                      Edit
                    </Button>
                  </Link>
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1 gap-1"
                    onClick={() => toggleStatus(campaign.id, campaign.status)}
                  >
                    {campaign.status === "active" ? (
                      <>
                        <Pause className="h-3 w-3" />
                        Pause
                      </>
                    ) : (
                      <>
                        <Play className="h-3 w-3" />
                        Activate
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
