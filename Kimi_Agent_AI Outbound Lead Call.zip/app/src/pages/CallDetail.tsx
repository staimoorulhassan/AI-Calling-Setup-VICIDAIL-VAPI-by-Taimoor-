import { useParams, Link } from "react-router";
import { trpc } from "@/providers/trpc";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  ArrowLeft,
  Phone,
  Clock,
  User,
  MessageSquare,
  PhoneForwarded,
  Play,
  Activity,
} from "lucide-react";

function StatusBadge({ status }: { status: string }) {
  const variants: Record<string, string> = {
    initiated: "bg-yellow-100 text-yellow-800",
    connected: "bg-blue-100 text-blue-800",
    qualifying_q1: "bg-purple-100 text-purple-800",
    qualifying_q2: "bg-purple-100 text-purple-800",
    qualifying_q3: "bg-purple-100 text-purple-800",
    transferring: "bg-orange-100 text-orange-800",
    transferred: "bg-green-100 text-green-800",
    completed: "bg-green-100 text-green-800",
    failed: "bg-red-100 text-red-800",
    voicemail: "bg-gray-100 text-gray-800",
    busy: "bg-red-100 text-red-800",
    no_answer: "bg-gray-100 text-gray-800",
  };
  return (
    <Badge variant="outline" className={variants[status] || ""}>
      {status.replace(/_/g, " ").toUpperCase()}
    </Badge>
  );
}

function EventIcon({ type }: { type: string }) {
  const iconMap: Record<string, any> = {
    dial: Phone,
    connect: Phone,
    tts_greeting: MessageSquare,
    ask_q1: MessageSquare,
    listen_q1: MessageSquare,
    ask_q2: MessageSquare,
    listen_q2: MessageSquare,
    ask_q3: MessageSquare,
    listen_q3: MessageSquare,
    announce_transfer: PhoneForwarded,
    initiate_3way: PhoneForwarded,
    bridge_confirmed: PhoneForwarded,
    ai_dropoff: Activity,
    verifier_join: User,
    hangup: Phone,
    error: Activity,
  };
  const Icon = iconMap[type] || Activity;
  return <Icon className="h-4 w-4" />;
}

function EventColor({ type }: { type: string }) {
  const colorMap: Record<string, string> = {
    dial: "bg-yellow-100 text-yellow-800",
    connect: "bg-blue-100 text-blue-800",
    tts_greeting: "bg-indigo-100 text-indigo-800",
    ask_q1: "bg-purple-100 text-purple-800",
    listen_q1: "bg-green-100 text-green-800",
    ask_q2: "bg-purple-100 text-purple-800",
    listen_q2: "bg-green-100 text-green-800",
    ask_q3: "bg-purple-100 text-purple-800",
    listen_q3: "bg-green-100 text-green-800",
    announce_transfer: "bg-orange-100 text-orange-800",
    initiate_3way: "bg-orange-100 text-orange-800",
    bridge_confirmed: "bg-green-100 text-green-800",
    ai_dropoff: "bg-gray-100 text-gray-800",
    verifier_join: "bg-blue-100 text-blue-800",
    hangup: "bg-red-100 text-red-800",
    error: "bg-red-100 text-red-800",
  };
  return colorMap[type] || "bg-gray-100 text-gray-800";
}

export default function CallDetail() {
  const { id } = useParams<{ id: string }>();
  const { data: call, isLoading } = trpc.call.getById.useQuery({ id: Number(id) });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  if (!call) {
    return (
      <div className="text-center py-16">
        <p className="text-muted-foreground">Call not found</p>
        <Link to="/calls">
          <Button variant="outline" className="mt-4">
            Back to Calls
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <div className="flex items-center gap-3">
        <Link to="/calls">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <div className="flex-1">
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold tracking-tight">Call #{call.id}</h1>
            <StatusBadge status={call.callStatus} />
          </div>
          <p className="text-sm text-muted-foreground">
            {call.vicidialCallId && `Vicidial ID: ${call.vicidialCallId}`}
          </p>
        </div>
        {call.recordingUrl && (
          <Button variant="outline" size="sm" className="gap-2">
            <Play className="h-4 w-4" />
            Play Recording
          </Button>
        )}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Call Info */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Phone className="h-5 w-5" />
              Call Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="p-3 rounded-lg bg-muted/50">
                <p className="text-xs text-muted-foreground mb-1">Lead</p>
                <p className="font-medium">
                  {call.leadFirstName} {call.leadLastName}
                </p>
                <p className="text-sm text-muted-foreground">{call.leadPhone}</p>
              </div>
              <div className="p-3 rounded-lg bg-muted/50">
                <p className="text-xs text-muted-foreground mb-1">Campaign</p>
                <p className="font-medium">{call.campaignName}</p>
              </div>
              <div className="p-3 rounded-lg bg-muted/50">
                <p className="text-xs text-muted-foreground mb-1">Duration</p>
                <p className="font-medium flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  {call.durationSeconds
                    ? `${Math.floor(call.durationSeconds / 60)}m ${call.durationSeconds % 60}s`
                    : "N/A"}
                </p>
              </div>
              <div className="p-3 rounded-lg bg-muted/50">
                <p className="text-xs text-muted-foreground mb-1">Transfer Status</p>
                <p className="font-medium flex items-center gap-1">
                  <PhoneForwarded className="h-4 w-4" />
                  {call.transferSuccess ? (
                    <span className="text-green-600">Successful</span>
                  ) : (
                    <span className="text-muted-foreground">Not Transferred</span>
                  )}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2 text-center">
              <div>
                <p className="text-xs text-muted-foreground">Started</p>
                <p className="text-sm font-medium">
                  {call.startedAt ? new Date(call.startedAt).toLocaleTimeString() : "N/A"}
                </p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Connected</p>
                <p className="text-sm font-medium">
                  {call.connectedAt ? new Date(call.connectedAt).toLocaleTimeString() : "N/A"}
                </p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Transferred</p>
                <p className="text-sm font-medium">
                  {call.transferredAt
                    ? new Date(call.transferredAt).toLocaleTimeString()
                    : "N/A"}
                </p>
              </div>
            </div>

            {call.hangupCause && (
              <div className="p-3 rounded-lg bg-red-50 border border-red-100">
                <p className="text-xs text-red-600 font-medium">Hangup Cause</p>
                <p className="text-sm text-red-700">{call.hangupCause}</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Question Answers */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessageSquare className="h-5 w-5" />
              Answers
            </CardTitle>
            <CardDescription>Qualifying questions and responses</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {call.answers && call.answers.length > 0 ? (
              call.answers.map((answer: any, idx: number) => (
                <div key={answer.id} className="p-3 rounded-lg border">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="h-5 w-5 rounded-full bg-primary/10 flex items-center justify-center text-xs font-medium">
                      {idx + 1}
                    </div>
                    <p className="text-xs font-medium text-muted-foreground">Q{idx + 1}</p>
                  </div>
                  <p className="text-sm mb-1">{answer.questionText}</p>
                  <p className="text-sm font-medium text-green-700 bg-green-50 p-2 rounded">
                    {answer.transcribedAnswer}
                  </p>
                  {answer.confidenceScore && (
                    <p className="text-xs text-muted-foreground mt-1">
                      Confidence: {Math.round(Number(answer.confidenceScore) * 100)}%
                    </p>
                  )}
                </div>
              ))
            ) : (
              <div className="text-center py-6 text-muted-foreground">
                <p className="text-sm">No answers recorded</p>
                <p className="text-xs">The call may have ended before questions were asked</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Call Timeline */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Call Timeline
          </CardTitle>
          <CardDescription>Chronological event log for this call</CardDescription>
        </CardHeader>
        <CardContent>
          {call.logs && call.logs.length > 0 ? (
            <div className="space-y-2">
              {call.logs.map((log: any) => (
                <div
                  key={log.id}
                  className="flex items-start gap-3 p-3 rounded-lg hover:bg-muted/30 transition-colors"
                >
                  <div className={`h-8 w-8 rounded-md flex items-center justify-center ${EventColor(log.eventType)}`}>
                    <EventIcon type={log.eventType} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-medium capitalize">
                        {log.eventType.replace(/_/g, " ")}
                      </p>
                      <span className="text-xs text-muted-foreground">
                        {new Date(log.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                    {log.eventData && (
                      <p className="text-xs text-muted-foreground mt-0.5 truncate">
                        {typeof log.eventData === "string"
                          ? log.eventData
                          : JSON.stringify(log.eventData).slice(0, 200)}
                      </p>
                    )}
                  </div>
                  {log.mossAudioUrl && (
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <Play className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <p className="text-sm">No events logged for this call</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
