import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Users, Search, Phone, Mail } from "lucide-react";

function StatusBadge({ status }: { status: string }) {
  const variants: Record<string, string> = {
    new: "bg-blue-100 text-blue-800",
    dialed: "bg-yellow-100 text-yellow-800",
    connected: "bg-green-100 text-green-800",
    qualified: "bg-purple-100 text-purple-800",
    not_qualified: "bg-red-100 text-red-800",
    not_interested: "bg-gray-100 text-gray-800",
    dnc: "bg-red-100 text-red-800",
    converted: "bg-green-100 text-green-800",
  };
  return (
    <Badge variant="outline" className={variants[status] || ""}>
      {status.replace(/_/g, " ").toUpperCase()}
    </Badge>
  );
}

export default function Leads() {
  const [filters, setFilters] = useState({
    status: "",
    search: "",
  });

  const { data, isLoading } = trpc.lead.list.useQuery({
    status: filters.status || undefined,
    search: filters.search || undefined,
    limit: 50,
  });

  const { data: stats } = trpc.lead.getStats.useQuery({});

  const leads = data?.leads || [];
  const total = data?.total || 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Leads</h1>
          <p className="text-sm text-muted-foreground">
            Manage your lead database synced from Vicidialer
          </p>
        </div>
        <div className="text-sm text-muted-foreground">{total} total leads</div>
      </div>

      {/* Stats */}
      {stats && (
        <div className="grid gap-3 grid-cols-4 lg:grid-cols-8">
          {[
            { label: "New", value: stats.new || 0, color: "bg-blue-100 text-blue-800" },
            { label: "Dialed", value: stats.dialed || 0, color: "bg-yellow-100 text-yellow-800" },
            { label: "Connected", value: stats.connected || 0, color: "bg-green-100 text-green-800" },
            { label: "Qualified", value: stats.qualified || 0, color: "bg-purple-100 text-purple-800" },
            { label: "Converted", value: stats.converted || 0, color: "bg-green-100 text-green-800" },
            { label: "Not Qual.", value: stats.notQualified || 0, color: "bg-red-100 text-red-800" },
            { label: "Not Int.", value: stats.notInterested || 0, color: "bg-gray-100 text-gray-800" },
            { label: "DNC", value: stats.dnc || 0, color: "bg-red-100 text-red-800" },
          ].map((s) => (
            <div key={s.label} className={`p-2 rounded-lg text-center ${s.color}`}>
              <div className="text-lg font-bold">{s.value}</div>
              <div className="text-[10px] font-medium">{s.label}</div>
            </div>
          ))}
        </div>
      )}

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-wrap gap-3">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search leads..."
                value={filters.search}
                onChange={(e) => setFilters({ ...filters, search: e.target.value })}
                className="pl-9"
              />
            </div>
            <Select value={filters.status} onValueChange={(v) => setFilters({ ...filters, status: v })}>
              <SelectTrigger className="w-[160px]">
                <SelectValue placeholder="All statuses" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All</SelectItem>
                <SelectItem value="new">New</SelectItem>
                <SelectItem value="dialed">Dialed</SelectItem>
                <SelectItem value="connected">Connected</SelectItem>
                <SelectItem value="qualified">Qualified</SelectItem>
                <SelectItem value="not_qualified">Not Qualified</SelectItem>
                <SelectItem value="not_interested">Not Interested</SelectItem>
                <SelectItem value="converted">Converted</SelectItem>
                <SelectItem value="dnc">DNC</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Leads Table */}
      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="text-center py-12 text-muted-foreground">Loading leads...</div>
          ) : leads.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Users className="h-12 w-12 mx-auto mb-3 opacity-30" />
              <p>No leads found</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b bg-muted/50">
                    <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase">Name</th>
                    <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase">Contact</th>
                    <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase">Campaign</th>
                    <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase">Status</th>
                    <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase">Calls</th>
                    <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase">Added</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {leads.map((lead) => (
                    <tr key={lead.id} className="hover:bg-muted/30 transition-colors">
                      <td className="px-4 py-3">
                        <div className="font-medium text-sm">
                          {lead.firstName} {lead.lastName}
                        </div>
                        {lead.vicidialLeadId && (
                          <div className="text-xs text-muted-foreground">VD: {lead.vicidialLeadId}</div>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1 text-sm">
                          <Phone className="h-3 w-3 text-muted-foreground" />
                          {lead.phoneNumber}
                        </div>
                        {lead.email && (
                          <div className="flex items-center gap-1 text-xs text-muted-foreground">
                            <Mail className="h-3 w-3" />
                            {lead.email}
                          </div>
                        )}
                      </td>
                      <td className="px-4 py-3 text-sm text-muted-foreground">{lead.campaignName}</td>
                      <td className="px-4 py-3">
                        <StatusBadge status={lead.status} />
                      </td>
                      <td className="px-4 py-3 text-sm text-muted-foreground">{lead.callCount}</td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">
                        {lead.createdAt ? new Date(lead.createdAt).toLocaleDateString() : "N/A"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
