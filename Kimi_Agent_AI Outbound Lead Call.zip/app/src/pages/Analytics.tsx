import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  BarChart3,
  Download,
  TrendingUp,
  Phone,
  PhoneForwarded,
  CheckCircle2,
  Filter,
} from "lucide-react";


export default function Analytics() {
  const [dateRange, setDateRange] = useState({
    from: "",
    to: "",
    campaignId: "",
  });

  const { data: dashboard } = trpc.analytics.getDashboard.useQuery({
    dateFrom: dateRange.from || undefined,
    dateTo: dateRange.to || undefined,
  });

  const { data: funnel } = trpc.analytics.getFunnel.useQuery({
    campaignId: dateRange.campaignId ? Number(dateRange.campaignId) : undefined,
    dateFrom: dateRange.from || undefined,
    dateTo: dateRange.to || undefined,
  });

  const { data: campaignPerf } = trpc.analytics.getCampaignPerf.useQuery({
    dateFrom: dateRange.from || undefined,
    dateTo: dateRange.to || undefined,
  });

  const { data: verifierPerf } = trpc.analytics.getVerifierPerf.useQuery({
    dateFrom: dateRange.from || undefined,
    dateTo: dateRange.to || undefined,
  });

  const overall = dashboard?.overall;

  const funnelSteps = funnel
    ? [
        { label: "Dialed", value: funnel.totalDialed, color: "bg-blue-500" },
        { label: "Connected", value: funnel.connected, color: "bg-green-500" },
        { label: "Q1 Answered", value: funnel.answeredQ1, color: "bg-purple-500" },
        { label: "Q2 Answered", value: funnel.answeredQ2, color: "bg-purple-600" },
        { label: "Q3 Answered", value: funnel.answeredQ3, color: "bg-purple-700" },
        { label: "Transferred", value: funnel.transferred, color: "bg-orange-500" },
        { label: "Completed", value: funnel.completed, color: "bg-green-600" },
      ]
    : [];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Analytics</h1>
          <p className="text-sm text-muted-foreground">
            Detailed reports and performance metrics
          </p>
        </div>
        <Button variant="outline" size="sm" className="gap-2">
          <Download className="h-4 w-4" />
          Export CSV
        </Button>
      </div>

      {/* Date Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-wrap gap-3 items-center">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <Input
              type="date"
              value={dateRange.from}
              onChange={(e) => setDateRange({ ...dateRange, from: e.target.value })}
              className="w-[160px]"
            />
            <span className="text-muted-foreground">to</span>
            <Input
              type="date"
              value={dateRange.to}
              onChange={(e) => setDateRange({ ...dateRange, to: e.target.value })}
              className="w-[160px]"
            />
            <Button
              variant="secondary"
              size="sm"
              onClick={() => {
                const today = new Date();
                const weekAgo = new Date(today.getTime() - 7 * 86400000);
                setDateRange({
                  ...dateRange,
                  from: weekAgo.toISOString().split("T")[0],
                  to: today.toISOString().split("T")[0],
                });
              }}
            >
              Last 7 Days
            </Button>
            <Button
              variant="secondary"
              size="sm"
              onClick={() => {
                const today = new Date();
                const monthAgo = new Date(today.getTime() - 30 * 86400000);
                setDateRange({
                  ...dateRange,
                  from: monthAgo.toISOString().split("T")[0],
                  to: today.toISOString().split("T")[0],
                });
              }}
            >
              Last 30 Days
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Overview Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-muted-foreground flex items-center gap-2">
              <Phone className="h-4 w-4" />
              Total Calls
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{overall?.totalCalls || 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-muted-foreground flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Connection Rate
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {overall?.totalCalls
                ? Math.round(((overall?.connected || 0) / overall.totalCalls) * 100)
                : 0}
              %
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-muted-foreground flex items-center gap-2">
              <PhoneForwarded className="h-4 w-4" />
              Transfer Rate
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {overall?.connected
                ? Math.round(((overall?.transferred || 0) / overall.connected) * 100)
                : 0}
              %
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-muted-foreground flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4" />
              Close Rate
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {overall?.transferred
                ? Math.round(((overall?.completed || 0) / overall.transferred) * 100)
                : 0}
              %
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Conversion Funnel */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Conversion Funnel
            </CardTitle>
            <CardDescription>Lead progression through the AI qualification flow</CardDescription>
          </CardHeader>
          <CardContent>
            {funnelSteps.length > 0 ? (
              <div className="space-y-3">
                {funnelSteps.map((step, idx) => {
                  const maxVal = Math.max(...funnelSteps.map((s) => s.value), 1);
                  const width = Math.max((step.value / maxVal) * 100, 5);
                  const prevValue = idx > 0 ? funnelSteps[idx - 1].value : step.value;
                  const conversionRate = idx > 0 && prevValue > 0
                    ? Math.round((step.value / prevValue) * 100)
                    : 100;

                  return (
                    <div key={step.label}>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-medium">{step.label}</span>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold">{step.value}</span>
                          {idx > 0 && (
                            <Badge variant="outline" className="text-xs">
                              {conversionRate}%
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div className="h-6 bg-muted rounded-full overflow-hidden">
                        <div
                          className={`h-full ${step.color} rounded-full transition-all flex items-center justify-end pr-2`}
                          style={{ width: `${width}%` }}
                        >
                          {width > 15 && <span className="text-xs text-white font-medium">{width > 30 ? step.label : ""}</span>}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">No funnel data available</div>
            )}
          </CardContent>
        </Card>

        {/* Campaign Performance */}
        <Card>
          <CardHeader>
            <CardTitle>Campaign Performance</CardTitle>
            <CardDescription>Compare performance across campaigns</CardDescription>
          </CardHeader>
          <CardContent>
            {campaignPerf && campaignPerf.length > 0 ? (
              <div className="space-y-3">
                {campaignPerf.map((cp: any) => (
                  <div key={cp.campaignId} className="p-3 rounded-lg border">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium truncate pr-2">{cp.campaignName}</span>
                      <Badge variant="outline" className="text-xs shrink-0">
                        {cp.totalCalls} calls
                      </Badge>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-center">
                      <div className="p-2 rounded bg-green-50">
                        <div className="text-sm font-bold text-green-700">{cp.connectedRate}%</div>
                        <div className="text-[10px] text-green-600">Connect</div>
                      </div>
                      <div className="p-2 rounded bg-orange-50">
                        <div className="text-sm font-bold text-orange-700">{cp.transferRate}%</div>
                        <div className="text-[10px] text-orange-600">Transfer</div>
                      </div>
                      <div className="p-2 rounded bg-blue-50">
                        <div className="text-sm font-bold text-blue-700">{cp.completionRate}%</div>
                        <div className="text-[10px] text-blue-600">Close</div>
                      </div>
                    </div>
                    <div className="text-xs text-muted-foreground mt-2">
                      Avg Duration: {Math.round(cp.avgDuration / 60)}m
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">No campaign data</div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Verifier Performance */}
      {verifierPerf && verifierPerf.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Verifier Performance</CardTitle>
            <CardDescription>Human verifier agents who handle transferred calls</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b bg-muted/50">
                    <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase">Verifier</th>
                    <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase">Calls Handled</th>
                    <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase">Avg Duration</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {verifierPerf.map((v: any) => (
                    <tr key={v.verifierId} className="hover:bg-muted/30">
                      <td className="px-4 py-3 text-sm font-medium">{v.verifierName}</td>
                      <td className="px-4 py-3 text-sm">{v.totalHandled}</td>
                      <td className="px-4 py-3 text-sm">
                        {Math.round(v.avgDuration / 60)}m {Math.round(v.avgDuration % 60)}s
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
