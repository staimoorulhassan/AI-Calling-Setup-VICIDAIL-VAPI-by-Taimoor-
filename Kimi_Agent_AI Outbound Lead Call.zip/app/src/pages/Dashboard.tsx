import { Link } from "react-router";
import { trpc } from "@/providers/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Phone,
  PhoneCall,
  PhoneForwarded,
  CheckCircle2,
  AlertCircle,
  Clock,
  TrendingUp,
  Megaphone,
  ArrowRight,
  Activity,
} from "lucide-react";

function StatCard({
  title,
  value,
  description,
  icon: Icon,
  trend,
  trendUp,
}: {
  title: string;
  value: string | number;
  description: string;
  icon: any;
  trend?: string;
  trendUp?: boolean;
}) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
        <div className="h-8 w-8 rounded-md bg-primary/10 flex items-center justify-center">
          <Icon className="h-4 w-4 text-primary" />
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <div className="flex items-center gap-2 mt-1">
          <p className="text-xs text-muted-foreground">{description}</p>
          {trend && (
            <span className={`text-xs font-medium flex items-center gap-0.5 ${trendUp ? "text-green-600" : "text-red-600"}`}>
              <TrendingUp className="h-3 w-3" />
              {trend}
            </span>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

function StatusBadge({ status }: { status: string }) {
  const variants: Record<string, string> = {
    initiated: "bg-yellow-100 text-yellow-800",
    connected: "bg-blue-100 text-blue-800",
    qualifying_q1: "bg-purple-100 text-purple-800",
    qualifying_q2: "bg-purple-100 text-purple-800",
    qualifying_q3: "bg-purple-100 text-purple-800",
    transferring: "bg-orange-100 text-orange-800",
    transferred: "bg-green-100 text-green-800",
    completed: "bg-green-100 text-green-800",
    failed: "bg-red-100 text-red-800",
    voicemail: "bg-gray-100 text-gray-800",
    busy: "bg-red-100 text-red-800",
    no_answer: "bg-gray-100 text-gray-800",
  };
  return (
    <Badge variant="outline" className={variants[status] || ""}>
      {status.replace(/_/g, " ").toUpperCase()}
    </Badge>
  );
}

export default function Dashboard() {
  const { data: dashboard } = trpc.analytics.getDashboard.useQuery({});
  const { data: activeCalls, isLoading: activeLoading } = trpc.call.getActive.useQuery();
  const { data: campaigns } = trpc.campaign.list.useQuery({ status: "active" });

  const overall = dashboard?.overall;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-sm text-muted-foreground">
            Monitor your AI outbound call campaigns in real-time
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5">
            <Activity className="h-4 w-4 text-green-500 animate-pulse" />
            <span className="text-sm font-medium">{activeCalls?.length || 0} Active</span>
          </div>
        </div>
      </div>

      {/* KPI Stats */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Total Calls"
          value={overall?.totalCalls || 0}
          description="All time calls"
          icon={Phone}
          trend="+12%"
          trendUp={true}
        />
        <StatCard
          title="Connected"
          value={overall?.connected || 0}
          description={`${overall?.totalCalls ? Math.round((overall.connected / overall.totalCalls) * 100) : 0}% connection rate`}
          icon={PhoneCall}
          trend="+8%"
          trendUp={true}
        />
        <StatCard
          title="Transferred"
          value={overall?.transferred || 0}
          description={`${overall?.connected ? Math.round((overall.transferred / overall.connected) * 100) : 0}% transfer rate`}
          icon={PhoneForwarded}
          trend="+15%"
          trendUp={true}
        />
        <StatCard
          title="Completed"
          value={overall?.completed || 0}
          description={`${overall?.transferred ? Math.round((overall.completed / overall.transferred) * 100) : 0}% close rate`}
          icon={CheckCircle2}
          trend="+5%"
          trendUp={true}
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Active Calls */}
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5 text-green-500" />
                Active Calls
                {activeCalls && activeCalls.length > 0 && (
                  <span className="text-xs bg-green-100 text-green-800 px-2 py-0.5 rounded-full">
                    {activeCalls.length} live
                  </span>
                )}
              </CardTitle>
            </div>
            <Link to="/calls">
              <Button variant="ghost" size="sm">
                View All <ArrowRight className="h-4 w-4 ml-1" />
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            {activeLoading ? (
              <div className="text-center py-8 text-muted-foreground">Loading active calls...</div>
            ) : !activeCalls || activeCalls.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Phone className="h-12 w-12 mx-auto mb-3 opacity-30" />
                <p>No active calls at the moment</p>
                <p className="text-xs mt-1">Calls will appear here when Vicidialer connects with leads</p>
              </div>
            ) : (
              <div className="space-y-3">
                {activeCalls.map((call) => (
                  <div
                    key={call.id}
                    className="flex items-center justify-between p-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                        <Phone className="h-4 w-4 text-primary" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">
                          {call.leadFirstName} {call.leadLastName}
                        </p>
                        <p className="text-xs text-muted-foreground">{call.leadPhone}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <p className="text-xs text-muted-foreground">{call.campaignName}</p>
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Clock className="h-3 w-3" />
                          {call.durationSeconds ? `${Math.floor(call.durationSeconds / 60)}m ${call.durationSeconds % 60}s` : "Just started"}
                        </div>
                      </div>
                      <StatusBadge status={call.callStatus} />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Active Campaigns */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Megaphone className="h-5 w-5" />
              Active Campaigns
            </CardTitle>
            <Link to="/campaigns">
              <Button variant="ghost" size="sm">
                Manage
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            {!campaigns || campaigns.length === 0 ? (
              <div className="text-center py-6 text-muted-foreground">
                <AlertCircle className="h-8 w-8 mx-auto mb-2 opacity-30" />
                <p className="text-sm">No active campaigns</p>
                <Link to="/campaigns/new">
                  <Button variant="outline" size="sm" className="mt-3">
                    Create Campaign
                  </Button>
                </Link>
              </div>
            ) : (
              <div className="space-y-3">
                {campaigns.map((campaign) => (
                  <Link
                    key={campaign.id}
                    to={`/campaigns/${campaign.id}/edit`}
                    className="block p-3 rounded-lg border hover:bg-accent/50 transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium truncate">{campaign.name}</p>
                      <Badge variant="outline" className="text-xs">
                        {campaign.language}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                      <span>{campaign.totalCalls} calls</span>
                      <span>{campaign.transferredCalls} xfer</span>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Daily Stats Chart */}
      {dashboard?.dailyStats && dashboard.dailyStats.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Daily Call Volume</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-end gap-2 h-32">
              {dashboard.dailyStats.map((day, i) => {
                const maxCalls = Math.max(...dashboard.dailyStats.map((d) => d.totalCalls), 1);
                const height = Math.max((day.totalCalls / maxCalls) * 100, 5);
                return (
                  <div key={i} className="flex-1 flex flex-col items-center gap-1">
                    <div className="text-xs text-muted-foreground">{day.totalCalls}</div>
                    <div
                      className="w-full bg-primary/80 rounded-t"
                      style={{ height: `${height}px` }}
                    />
                    <div className="text-[10px] text-muted-foreground truncate w-full text-center">
                      {new Date(day.date).toLocaleDateString("en", { month: "short", day: "numeric" })}
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
