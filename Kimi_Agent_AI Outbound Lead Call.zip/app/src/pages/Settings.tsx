import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import {
  Settings,
  Phone,
  Volume2,
  Server,
  Save,
} from "lucide-react";

export default function SettingsPage() {
  const [settings, setSettings] = useState({
    // Vicidial
    vicidialUrl: "",
    vicidialApiKey: "",
    vicidialUser: "",
    // AMI
    amiHost: "",
    amiPort: "5038",
    amiUsername: "",
    amiSecret: "",
    // AVR
    avrCoreUrl: "http://avr-core:5000",
    avrAudioSocketPort: "5001",
    // MOSS-TTS
    mossTtsUrl: "http://moss-tts:8080",
    mossDefaultVoice: "en-US-female-1",
    // System
    maxConcurrentCalls: "50",
    ttsTimeout: "5000",
    transferTimeout: "30",
  });

  const handleSave = () => {
    toast.success("Settings saved successfully");
  };

  const handleTestConnection = (service: string) => {
    toast.info(`Testing ${service} connection...`);
    setTimeout(() => {
      toast.success(`${service} connection successful`);
    }, 1500);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Settings</h1>
        <p className="text-sm text-muted-foreground">
          Configure integrations with Vicidialer, AVR, and MOSS-TTS
        </p>
      </div>

      {/* Vicidialer Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Phone className="h-5 w-5 text-primary" />
            Vicidialer Integration
          </CardTitle>
          <CardDescription>Connect to your Vicidialer server for campaign and lead sync</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="vdUrl">Vicidial URL</Label>
              <Input
                id="vdUrl"
                value={settings.vicidialUrl}
                onChange={(e) => setSettings({ ...settings, vicidialUrl: e.target.value })}
                placeholder="http://vicidial-server/vicidial"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="vdApiKey">API Key</Label>
              <Input
                id="vdApiKey"
                type="password"
                value={settings.vicidialApiKey}
                onChange={(e) => setSettings({ ...settings, vicidialApiKey: e.target.value })}
                placeholder="Your Vicidial API key"
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="vdUser">API Username</Label>
            <Input
              id="vdUser"
              value={settings.vicidialUser}
              onChange={(e) => setSettings({ ...settings, vicidialUser: e.target.value })}
              placeholder="admin"
            />
          </div>
          <Button variant="outline" size="sm" onClick={() => handleTestConnection("Vicidial")}>
            Test Connection
          </Button>
        </CardContent>
      </Card>

      {/* Asterisk AMI */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Server className="h-5 w-5 text-primary" />
            Asterisk Manager Interface (AMI)
          </CardTitle>
          <CardDescription>Configure AMI for call control and 3-way transfers</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="amiHost">AMI Host</Label>
              <Input
                id="amiHost"
                value={settings.amiHost}
                onChange={(e) => setSettings({ ...settings, amiHost: e.target.value })}
                placeholder="asterisk-server"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="amiPort">AMI Port</Label>
              <Input
                id="amiPort"
                value={settings.amiPort}
                onChange={(e) => setSettings({ ...settings, amiPort: e.target.value })}
                placeholder="5038"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="amiUser">Username</Label>
              <Input
                id="amiUser"
                value={settings.amiUsername}
                onChange={(e) => setSettings({ ...settings, amiUsername: e.target.value })}
                placeholder="admin"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="amiSecret">Secret</Label>
              <Input
                id="amiSecret"
                type="password"
                value={settings.amiSecret}
                onChange={(e) => setSettings({ ...settings, amiSecret: e.target.value })}
                placeholder="amp111"
              />
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={() => handleTestConnection("AMI")}>
            Test Connection
          </Button>
        </CardContent>
      </Card>

      {/* AVR Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Volume2 className="h-5 w-5 text-primary" />
            AVR (Agent Voice Response)
          </CardTitle>
          <CardDescription>Configure AVR Core and AudioSocket settings</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="avrUrl">AVR Core URL</Label>
              <Input
                id="avrUrl"
                value={settings.avrCoreUrl}
                onChange={(e) => setSettings({ ...settings, avrCoreUrl: e.target.value })}
                placeholder="http://avr-core:5000"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="avrPort">AudioSocket Port</Label>
              <Input
                id="avrPort"
                value={settings.avrAudioSocketPort}
                onChange={(e) => setSettings({ ...settings, avrAudioSocketPort: e.target.value })}
                placeholder="5001"
              />
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={() => handleTestConnection("AVR")}>
            Test Connection
          </Button>
        </CardContent>
      </Card>

      {/* MOSS-TTS Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Volume2 className="h-5 w-5 text-primary" />
            MOSS-TTS
          </CardTitle>
          <CardDescription>Configure MOSS Text-to-Speech engine</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="mossUrl">MOSS-TTS URL</Label>
              <Input
                id="mossUrl"
                value={settings.mossTtsUrl}
                onChange={(e) => setSettings({ ...settings, mossTtsUrl: e.target.value })}
                placeholder="http://moss-tts:8080"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="mossVoice">Default Voice</Label>
              <Input
                id="mossVoice"
                value={settings.mossDefaultVoice}
                onChange={(e) => setSettings({ ...settings, mossDefaultVoice: e.target.value })}
                placeholder="en-US-female-1"
              />
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={() => handleTestConnection("MOSS-TTS")}>
            Test Connection
          </Button>
        </CardContent>
      </Card>

      {/* System Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5 text-primary" />
            System Configuration
          </CardTitle>
          <CardDescription>General system behavior settings</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="maxCalls">Max Concurrent Calls</Label>
              <Input
                id="maxCalls"
                type="number"
                value={settings.maxConcurrentCalls}
                onChange={(e) => setSettings({ ...settings, maxConcurrentCalls: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="ttsTimeout">TTS Timeout (ms)</Label>
              <Input
                id="ttsTimeout"
                type="number"
                value={settings.ttsTimeout}
                onChange={(e) => setSettings({ ...settings, ttsTimeout: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="xferTimeout">Transfer Timeout (sec)</Label>
              <Input
                id="xferTimeout"
                type="number"
                value={settings.transferTimeout}
                onChange={(e) => setSettings({ ...settings, transferTimeout: e.target.value })}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button onClick={handleSave} className="gap-2">
          <Save className="h-4 w-4" />
          Save All Settings
        </Button>
      </div>
    </div>
  );
}

