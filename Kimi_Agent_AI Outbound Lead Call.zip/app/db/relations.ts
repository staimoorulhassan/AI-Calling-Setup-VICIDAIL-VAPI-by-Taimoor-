import { relations } from "drizzle-orm";
import {
  campaigns,
  qualifyingQuestions,
  leads,
  callSessions,
  questionAnswers,
  callLogs,
  verifiers,
} from "./schema";

export const campaignsRelations = relations(campaigns, ({ many }) => ({
  questions: many(qualifyingQuestions),
  leads: many(leads),
  callSessions: many(callSessions),
}));

export const qualifyingQuestionsRelations = relations(qualifyingQuestions, ({ one, many }) => ({
  campaign: one(campaigns, {
    fields: [qualifyingQuestions.campaignId],
    references: [campaigns.id],
  }),
  answers: many(questionAnswers),
}));

export const leadsRelations = relations(leads, ({ one, many }) => ({
  campaign: one(campaigns, {
    fields: [leads.campaignId],
    references: [campaigns.id],
  }),
  callSessions: many(callSessions),
}));

export const callSessionsRelations = relations(callSessions, ({ one, many }) => ({
  lead: one(leads, {
    fields: [callSessions.leadId],
    references: [leads.id],
  }),
  campaign: one(campaigns, {
    fields: [callSessions.campaignId],
    references: [campaigns.id],
  }),
  verifier: one(verifiers, {
    fields: [callSessions.verifierId],
    references: [verifiers.id],
  }),
  questionAnswers: many(questionAnswers),
  callLogs: many(callLogs),
}));

export const questionAnswersRelations = relations(questionAnswers, ({ one }) => ({
  callSession: one(callSessions, {
    fields: [questionAnswers.callSessionId],
    references: [callSessions.id],
  }),
  question: one(qualifyingQuestions, {
    fields: [questionAnswers.questionId],
    references: [qualifyingQuestions.id],
  }),
}));

export const callLogsRelations = relations(callLogs, ({ one }) => ({
  callSession: one(callSessions, {
    fields: [callLogs.callSessionId],
    references: [callSessions.id],
  }),
}));

export const verifiersRelations = relations(verifiers, ({ many }) => ({
  callSessions: many(callSessions),
}));
