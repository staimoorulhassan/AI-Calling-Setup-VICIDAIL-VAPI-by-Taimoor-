import { getDb } from "../api/queries/connection";
import {
  campaigns,
  qualifyingQuestions,
  leads,
  verifiers,
  systemSettings,
  callSessions,
} from "./schema";

async function seed() {
  const db = getDb();
  console.log("Seeding database...");

  // Seed verifiers
  const verifierData = [
    { name: "John Smith", vicidialUserId: "VERIFIER-1", extension: "8001", status: "online" as const, maxConcurrentCalls: 2 },
    { name: "Jane Doe", vicidialUserId: "VERIFIER-2", extension: "8002", status: "online" as const, maxConcurrentCalls: 2 },
    { name: "Bob Wilson", vicidialUserId: "VERIFIER-3", extension: "8003", status: "offline" as const, maxConcurrentCalls: 1 },
    { name: "Sarah Chen", vicidialUserId: "VERIFIER-4", extension: "8004", status: "online" as const, maxConcurrentCalls: 3 },
  ];

  for (const v of verifierData) {
    await db.insert(verifiers).values(v);
  }
  console.log("  Verifiers seeded");

  // Seed demo campaign
  const [campaignResult] = await db.insert(campaigns).values({
    name: "Home Insurance Lead Gen Q2",
    vicidialCampaignId: "INS-Q2-2026",
    status: "active",
    greetingMessage: "Hello! This is an important call about home insurance savings in your area. My name is Alice. May I have a quick moment of your time?",
    closingMessage: "Thank you so much for your time! I'm now connecting you with one of our licensed insurance specialists who can provide you with a personalized quote. Please hold just a moment.",
    transferMessage: "Connecting you now with a specialist. They have all the information you just provided.",
    mossVoiceId: "en-US-female-1",
    language: "en-US",
    ttsSpeed: "1.00",
    ttsPitch: "1.00",
    verifierIngroup: "INSURANCE-VERIFIERS",
    verifierExtension: "8801",
  });

  const campaignId = Number(campaignResult.insertId);
  console.log(`  Campaign created: ID ${campaignId}`);

  // Seed 3 qualifying questions
  const questionsData = [
    {
      campaignId,
      questionOrder: 1,
      questionText: "Do you currently own or rent your home?",
      expectedAnswerType: "choice" as const,
      validationRules: JSON.stringify({ choices: ["own", "rent"], allowOther: false }),
      isRequired: true,
    },
    {
      campaignId,
      questionOrder: 2,
      questionText: "And roughly how much do you currently pay for your home insurance per month?",
      expectedAnswerType: "numeric" as const,
      validationRules: JSON.stringify({ min: 0, max: 5000, unit: "dollars" }),
      isRequired: true,
    },
    {
      campaignId,
      questionOrder: 3,
      questionText: "Great! Based on your answers, you may qualify for significant savings. Would you like to speak with a licensed insurance specialist about a personalized quote today?",
      expectedAnswerType: "yes_no" as const,
      validationRules: JSON.stringify({ positiveKeywords: ["yes", "yeah", "sure", "absolutely", "definitely"] }),
      isRequired: true,
    },
  ];

  await db.insert(qualifyingQuestions).values(questionsData);
  console.log("  Qualifying questions seeded");

  // Seed demo leads
  const leadsData = [
    { phoneNumber: "+1-555-0101", firstName: "Michael", lastName: "Johnson", email: "michael.j@email.com", vicidialLeadId: "VD-1001", listId: "LIST-1", campaignId, status: "new" as const },
    { phoneNumber: "+1-555-0102", firstName: "Emily", lastName: "Davis", email: "emily.d@email.com", vicidialLeadId: "VD-1002", listId: "LIST-1", campaignId, status: "new" as const },
    { phoneNumber: "+1-555-0103", firstName: "David", lastName: "Brown", email: "david.b@email.com", vicidialLeadId: "VD-1003", listId: "LIST-1", campaignId, status: "new" as const },
    { phoneNumber: "+1-555-0104", firstName: "Lisa", lastName: "Wilson", email: "lisa.w@email.com", vicidialLeadId: "VD-1004", listId: "LIST-1", campaignId, status: "new" as const },
    { phoneNumber: "+1-555-0105", firstName: "Robert", lastName: "Taylor", email: "robert.t@email.com", vicidialLeadId: "VD-1005", listId: "LIST-1", campaignId, status: "new" as const },
    { phoneNumber: "+1-555-0106", firstName: "Jennifer", lastName: "Anderson", email: "jennifer.a@email.com", vicidialLeadId: "VD-1006", listId: "LIST-2", campaignId, status: "dialed" as const },
    { phoneNumber: "+1-555-0107", firstName: "James", lastName: "Thomas", email: "james.t@email.com", vicidialLeadId: "VD-1007", listId: "LIST-2", campaignId, status: "connected" as const },
    { phoneNumber: "+1-555-0108", firstName: "Maria", lastName: "Garcia", email: "maria.g@email.com", vicidialLeadId: "VD-1008", listId: "LIST-2", campaignId, status: "qualified" as const },
    { phoneNumber: "+1-555-0109", firstName: "William", lastName: "Martinez", email: "william.m@email.com", vicidialLeadId: "VD-1009", listId: "LIST-2", campaignId, status: "converted" as const },
    { phoneNumber: "+1-555-0110", firstName: "Patricia", lastName: "Robinson", email: "patricia.r@email.com", vicidialLeadId: "VD-1010", listId: "LIST-2", campaignId, status: "not_interested" as const },
  ];

  await db.insert(leads).values(leadsData);
  console.log("  Leads seeded");

  // Seed system settings
  const settingsData = [
    { key: "vicidial_url", value: "", category: "integration", description: "Vicidialer server URL" },
    { key: "vicidial_api_key", value: "", category: "integration", description: "Vicidialer API key" },
    { key: "ami_host", value: "", category: "integration", description: "Asterisk AMI host" },
    { key: "ami_port", value: "5038", category: "integration", description: "Asterisk AMI port" },
    { key: "avr_core_url", value: "http://avr-core:5000", category: "voice", description: "AVR Core service URL" },
    { key: "moss_tts_url", value: "http://moss-tts:8080", category: "voice", description: "MOSS-TTS service URL" },
    { key: "asr_provider", value: "deepgram", category: "voice", description: "ASR provider (deepgram/whisper/vosk)" },
    { key: "max_concurrent_calls", value: "50", category: "system", description: "Maximum concurrent AI calls" },
    { key: "tts_timeout_ms", value: "5000", category: "voice", description: "TTS request timeout in milliseconds" },
    { key: "transfer_timeout_sec", value: "30", category: "system", description: "Transfer timeout in seconds" },
  ];

  await db.insert(systemSettings).values(settingsData);
  console.log("  System settings seeded");

  // Seed some demo call sessions for analytics
  const demoCallSessions = [
    { leadId: 6, campaignId, callStatus: "completed" as const, transferSuccess: true, durationSeconds: 245, startedAt: new Date(Date.now() - 86400000 * 1), connectedAt: new Date(Date.now() - 86400000 * 1 + 5000), transferredAt: new Date(Date.now() - 86400000 * 1 + 120000), endedAt: new Date(Date.now() - 86400000 * 1 + 245000) },
    { leadId: 7, campaignId, callStatus: "completed" as const, transferSuccess: true, durationSeconds: 312, startedAt: new Date(Date.now() - 86400000 * 2), connectedAt: new Date(Date.now() - 86400000 * 2 + 3000), transferredAt: new Date(Date.now() - 86400000 * 2 + 180000), endedAt: new Date(Date.now() - 86400000 * 2 + 312000) },
    { leadId: 8, campaignId, callStatus: "completed" as const, transferSuccess: false, durationSeconds: 45, startedAt: new Date(Date.now() - 86400000 * 2), connectedAt: new Date(Date.now() - 86400000 * 2 + 4000), endedAt: new Date(Date.now() - 86400000 * 2 + 45000), hangupCause: "no_verifier_available" },
    { leadId: 9, campaignId, callStatus: "no_answer" as const, durationSeconds: null, startedAt: new Date(Date.now() - 86400000 * 3), endedAt: new Date(Date.now() - 86400000 * 3 + 30000) },
    { leadId: 10, campaignId, callStatus: "completed" as const, transferSuccess: true, durationSeconds: 189, startedAt: new Date(Date.now() - 86400000 * 3), connectedAt: new Date(Date.now() - 86400000 * 3 + 6000), transferredAt: new Date(Date.now() - 86400000 * 3 + 90000), endedAt: new Date(Date.now() - 86400000 * 3 + 189000) },
  ];

  await db.insert(callSessions).values(demoCallSessions);
  console.log("  Demo call sessions seeded");

  console.log("\nSeed complete!");
}

seed().catch(console.error);
