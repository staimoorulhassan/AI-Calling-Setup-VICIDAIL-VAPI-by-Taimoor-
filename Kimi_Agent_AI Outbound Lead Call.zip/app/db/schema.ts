import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  bigint,
  int,
  decimal,
  json,
  boolean,
  uniqueIndex,
} from "drizzle-orm/mysql-core";

// ─── Users (Auth) ──────────────────────────────────────────────
export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Campaigns ─────────────────────────────────────────────────
export const campaigns = mysqlTable("campaigns", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  vicidialCampaignId: varchar("vicidial_campaign_id", { length: 50 }).notNull(),
  status: mysqlEnum("status", ["active", "inactive", "paused"]).default("inactive").notNull(),
  greetingMessage: text("greeting_message").notNull(),
  closingMessage: text("closing_message"),
  transferMessage: text("transfer_message"),
  mossVoiceId: varchar("moss_voice_id", { length: 100 }).notNull(),
  language: varchar("language", { length: 10 }).default("en-US").notNull(),
  ttsSpeed: decimal("tts_speed", { precision: 3, scale: 2 }).default("1.00").notNull(),
  ttsPitch: decimal("tts_pitch", { precision: 3, scale: 2 }).default("1.00").notNull(),
  verifierIngroup: varchar("verifier_ingroup", { length: 100 }).notNull(),
  verifierExtension: varchar("verifier_extension", { length: 50 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Campaign = typeof campaigns.$inferSelect;
export type InsertCampaign = typeof campaigns.$inferInsert;

// ─── Qualifying Questions ──────────────────────────────────────
export const qualifyingQuestions = mysqlTable(
  "qualifying_questions",
  {
    id: serial("id").primaryKey(),
    campaignId: bigint("campaign_id", { mode: "number", unsigned: true }).notNull(),
    questionOrder: int("question_order").notNull(),
    questionText: text("question_text").notNull(),
    expectedAnswerType: mysqlEnum("expected_answer_type", ["yes_no", "numeric", "text", "choice"])
      .default("text")
      .notNull(),
    validationRules: json("validation_rules"),
    isRequired: boolean("is_required").default(true).notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex("campaign_order_idx").on(table.campaignId, table.questionOrder),
  ]
);

export type QualifyingQuestion = typeof qualifyingQuestions.$inferSelect;
export type InsertQualifyingQuestion = typeof qualifyingQuestions.$inferInsert;

// ─── Leads ─────────────────────────────────────────────────────
export const leads = mysqlTable("leads", {
  id: serial("id").primaryKey(),
  phoneNumber: varchar("phone_number", { length: 20 }).notNull(),
  firstName: varchar("first_name", { length: 100 }),
  lastName: varchar("last_name", { length: 100 }),
  email: varchar("email", { length: 255 }),
  vicidialLeadId: varchar("vicidial_lead_id", { length: 50 }),
  listId: varchar("list_id", { length: 50 }),
  campaignId: bigint("campaign_id", { mode: "number", unsigned: true }).notNull(),
  status: mysqlEnum("status", [
    "new",
    "dialed",
    "connected",
    "qualified",
    "not_qualified",
    "not_interested",
    "dnc",
    "converted",
  ])
    .default("new")
    .notNull(),
  customFields: json("custom_fields"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Lead = typeof leads.$inferSelect;
export type InsertLead = typeof leads.$inferInsert;

// ─── Call Sessions ─────────────────────────────────────────────
export const callSessions = mysqlTable("call_sessions", {
  id: serial("id").primaryKey(),
  leadId: bigint("lead_id", { mode: "number", unsigned: true }).notNull(),
  campaignId: bigint("campaign_id", { mode: "number", unsigned: true }).notNull(),
  vicidialCallId: varchar("vicidial_call_id", { length: 100 }),
  callStatus: mysqlEnum("call_status", [
    "initiated",
    "connected",
    "qualifying_q1",
    "qualifying_q2",
    "qualifying_q3",
    "transferring",
    "transferred",
    "completed",
    "failed",
    "voicemail",
    "busy",
    "no_answer",
  ])
    .default("initiated")
    .notNull(),
  verifierId: bigint("verifier_id", { mode: "number", unsigned: true }),
  startedAt: timestamp("started_at"),
  connectedAt: timestamp("connected_at"),
  transferredAt: timestamp("transferred_at"),
  endedAt: timestamp("ended_at"),
  durationSeconds: int("duration_seconds"),
  transferSuccess: boolean("transfer_success").default(false).notNull(),
  recordingUrl: varchar("recording_url", { length: 500 }),
  hangupCause: varchar("hangup_cause", { length: 50 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type CallSession = typeof callSessions.$inferSelect;
export type InsertCallSession = typeof callSessions.$inferInsert;

// ─── Question Answers ──────────────────────────────────────────
export const questionAnswers = mysqlTable("question_answers", {
  id: serial("id").primaryKey(),
  callSessionId: bigint("call_session_id", { mode: "number", unsigned: true }).notNull(),
  questionId: bigint("question_id", { mode: "number", unsigned: true }).notNull(),
  questionText: text("question_text").notNull(),
  transcribedAnswer: text("transcribed_answer"),
  confidenceScore: decimal("confidence_score", { precision: 5, scale: 4 }),
  answeredAt: timestamp("answered_at"),
  isValid: boolean("is_valid").default(true).notNull(),
});

export type QuestionAnswer = typeof questionAnswers.$inferSelect;
export type InsertQuestionAnswer = typeof questionAnswers.$inferInsert;

// ─── Call Logs ─────────────────────────────────────────────────
export const callLogs = mysqlTable("call_logs", {
  id: serial("id").primaryKey(),
  callSessionId: bigint("call_session_id", { mode: "number", unsigned: true }).notNull(),
  eventType: mysqlEnum("event_type", [
    "dial",
    "connect",
    "tts_greeting",
    "ask_q1",
    "listen_q1",
    "ask_q2",
    "listen_q2",
    "ask_q3",
    "listen_q3",
    "announce_transfer",
    "initiate_3way",
    "bridge_confirmed",
    "ai_dropoff",
    "verifier_join",
    "hangup",
    "error",
  ]).notNull(),
  eventData: json("event_data"),
  mossAudioUrl: varchar("moss_audio_url", { length: 500 }),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export type CallLog = typeof callLogs.$inferSelect;
export type InsertCallLog = typeof callLogs.$inferInsert;

// ─── Verifiers ─────────────────────────────────────────────────
export const verifiers = mysqlTable("verifiers", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  vicidialUserId: varchar("vicidial_user_id", { length: 50 }),
  extension: varchar("extension", { length: 50 }),
  status: mysqlEnum("status", ["online", "offline", "busy"]).default("offline").notNull(),
  maxConcurrentCalls: int("max_concurrent_calls").default(1).notNull(),
  currentCalls: int("current_calls").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Verifier = typeof verifiers.$inferSelect;
export type InsertVerifier = typeof verifiers.$inferInsert;

// ─── System Settings ───────────────────────────────────────────
export const systemSettings = mysqlTable("system_settings", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 100 }).notNull().unique(),
  value: text("value"),
  category: varchar("category", { length: 50 }).notNull(),
  description: text("description"),
  updatedAt: timestamp("updated_at")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type SystemSetting = typeof systemSettings.$inferSelect;
export type InsertSystemSetting = typeof systemSettings.$inferInsert;
