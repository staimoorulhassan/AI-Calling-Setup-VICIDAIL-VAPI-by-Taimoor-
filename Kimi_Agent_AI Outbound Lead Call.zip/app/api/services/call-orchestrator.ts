/**
 * Call Orchestration Service
 * Manages the 5-step call flow:
 * 1. Vicidialer dials lead
 * 2. Human answers -> AVR bridges
 * 3. AI asks 3 qualifying questions
 * 4. 3-way transfer to verifier
 * 5. AI drops, verifier continues
 */

import { getDb } from "../queries/connection";
import {
  campaigns,
  qualifyingQuestions,
  callSessions,
  questionAnswers,
  callLogs,
  verifiers,
} from "@db/schema";
import { eq, and } from "drizzle-orm";

export type CallState =
  | "initiated"
  | "connected"
  | "qualifying_q1"
  | "qualifying_q2"
  | "qualifying_q3"
  | "transferring"
  | "transferred"
  | "completed"
  | "failed"
  | "voicemail"
  | "busy"
  | "no_answer";

export class CallOrchestrator {
  /**
   * Step 1: Handle new outbound call initiated by Vicidialer
   */
  static async initiateCall(params: {
    leadId: number;
    campaignId: number;
    vicidialCallId?: string;
  }): Promise<number> {
    const db = getDb();
    const [session] = await db.insert(callSessions).values({
      leadId: params.leadId,
      campaignId: params.campaignId,
      vicidialCallId: params.vicidialCallId || null,
      callStatus: "initiated",
      startedAt: new Date(),
    });

    const sessionId = Number(session.insertId);

    await db.insert(callLogs).values({
      callSessionId: sessionId,
      eventType: "dial",
      eventData: { vicidialCallId: params.vicidialCallId },
    });

    return sessionId;
  }

  /**
   * Step 2: Handle call connected - AVR bridges to AI agent
   */
  static async handleConnected(sessionId: number): Promise<{
    sessionId: number;
    campaignConfig: any;
    questions: any[];
  }> {
    const db = getDb();

    await db
      .update(callSessions)
      .set({ callStatus: "connected", connectedAt: new Date() })
      .where(eq(callSessions.id, sessionId));

    await db.insert(callLogs).values({
      callSessionId: sessionId,
      eventType: "connect",
    });

    // Get campaign config with questions
    const [session] = await db
      .select()
      .from(callSessions)
      .where(eq(callSessions.id, sessionId));

    const [campaign] = await db
      .select()
      .from(campaigns)
      .where(eq(campaigns.id, session.campaignId));

    const questions = await db
      .select()
      .from(qualifyingQuestions)
      .where(eq(qualifyingQuestions.campaignId, session.campaignId))
      .orderBy(qualifyingQuestions.questionOrder);

    return {
      sessionId,
      campaignConfig: campaign,
      questions,
    };
  }

  /**
   * Step 3a: Play greeting TTS
   */
  static async playGreeting(sessionId: number, greetingText: string): Promise<void> {
    const db = getDb();
    await db
      .update(callSessions)
      .set({ callStatus: "qualifying_q1" })
      .where(eq(callSessions.id, sessionId));

    await db.insert(callLogs).values({
      callSessionId: sessionId,
      eventType: "tts_greeting",
      eventData: { greetingText },
    });
  }

  /**
   * Step 3b: Ask a qualifying question (Q1, Q2, Q3)
   */
  static async askQuestion(
    sessionId: number,
    questionIndex: 1 | 2 | 3,
    questionText: string
  ): Promise<void> {
    const db = getDb();
    const statusMap = {
      1: "qualifying_q1" as const,
      2: "qualifying_q2" as const,
      3: "qualifying_q3" as const,
    };

    await db
      .update(callSessions)
      .set({ callStatus: statusMap[questionIndex] })
      .where(eq(callSessions.id, sessionId));

    await db.insert(callLogs).values({
      callSessionId: sessionId,
      eventType: `ask_q${questionIndex}` as any,
      eventData: { questionText, questionIndex },
    });
  }

  /**
   * Step 3c: Receive and store answer
   */
  static async receiveAnswer(params: {
    sessionId: number;
    questionId: number;
    questionText: string;
    transcribedAnswer: string;
    confidenceScore?: number;
    questionIndex: 1 | 2 | 3;
  }): Promise<void> {
    const db = getDb();

    await db.insert(questionAnswers).values({
      callSessionId: params.sessionId,
      questionId: params.questionId,
      questionText: params.questionText,
      transcribedAnswer: params.transcribedAnswer,
      confidenceScore: params.confidenceScore ? String(params.confidenceScore) : null,
      answeredAt: new Date(),
    });

    await db.insert(callLogs).values({
      callSessionId: params.sessionId,
      eventType: `listen_q${params.questionIndex}` as any,
      eventData: {
        answer: params.transcribedAnswer,
        confidence: params.confidenceScore,
      },
    });
  }

  /**
   * Step 4a: Announce transfer to verifier
   */
  static async announceTransfer(
    sessionId: number,
    transferMessage: string
  ): Promise<void> {
    const db = getDb();

    await db.insert(callLogs).values({
      callSessionId: sessionId,
      eventType: "announce_transfer",
      eventData: { transferMessage },
    });
  }

  /**
   * Step 4b: Initiate 3-way transfer
   */
  static async initiateTransfer(
    sessionId: number,
    verifierIngroup: string
  ): Promise<{ success: boolean; verifierId?: number }> {
    const db = getDb();

    await db
      .update(callSessions)
      .set({ callStatus: "transferring" })
      .where(eq(callSessions.id, sessionId));

    await db.insert(callLogs).values({
      callSessionId: sessionId,
      eventType: "initiate_3way",
      eventData: { verifierIngroup },
    });

    // Find available verifier
    const [availableVerifier] = await db
      .select()
      .from(verifiers)
      .where(and(eq(verifiers.status, "online"), eq(verifiers.currentCalls, 0)))
      .limit(1);

    if (availableVerifier) {
      await db
        .update(verifiers)
        .set({
          status: "busy",
          currentCalls: availableVerifier.currentCalls + 1,
        })
        .where(eq(verifiers.id, availableVerifier.id));

      await db
        .update(callSessions)
        .set({ verifierId: availableVerifier.id })
        .where(eq(callSessions.id, sessionId));

      return { success: true, verifierId: availableVerifier.id };
    }

    return { success: false };
  }

  /**
   * Step 4c: Confirm bridge between lead and verifier
   */
  static async confirmBridge(sessionId: number): Promise<void> {
    const db = getDb();

    await db
      .update(callSessions)
      .set({ callStatus: "transferred", transferSuccess: true, transferredAt: new Date() })
      .where(eq(callSessions.id, sessionId));

    await db.insert(callLogs).values({
      callSessionId: sessionId,
      eventType: "bridge_confirmed",
    });
  }

  /**
   * Step 5: AI agent drops off the call
   */
  static async agentDropoff(sessionId: number): Promise<void> {
    const db = getDb();

    await db.insert(callLogs).values({
      callSessionId: sessionId,
      eventType: "ai_dropoff",
    });
  }

  /**
   * Handle call completion by verifier
   */
  static async completeCall(sessionId: number, disposition?: string): Promise<void> {
    const db = getDb();
    const [session] = await db
      .select()
      .from(callSessions)
      .where(eq(callSessions.id, sessionId));

    const duration = session.connectedAt
      ? Math.floor((new Date().getTime() - new Date(session.connectedAt).getTime()) / 1000)
      : null;

    await db
      .update(callSessions)
      .set({
        callStatus: "completed",
        endedAt: new Date(),
        durationSeconds: duration,
      })
      .where(eq(callSessions.id, sessionId));

    // Free up verifier
    if (session.verifierId) {
      const [verifier] = await db
        .select()
        .from(verifiers)
        .where(eq(verifiers.id, session.verifierId));

      if (verifier) {
        await db
          .update(verifiers)
          .set({
            status: verifier.currentCalls <= 1 ? "online" : "busy",
            currentCalls: Math.max(0, verifier.currentCalls - 1),
          })
          .where(eq(verifiers.id, session.verifierId));
      }
    }

    await db.insert(callLogs).values({
      callSessionId: sessionId,
      eventType: "hangup",
      eventData: { disposition },
    });
  }

  /**
   * Handle call failure
   */
  static async handleFailure(
    sessionId: number,
    cause: "failed" | "voicemail" | "busy" | "no_answer",
    details?: string
  ): Promise<void> {
    const db = getDb();

    await db
      .update(callSessions)
      .set({
        callStatus: cause,
        endedAt: new Date(),
        hangupCause: details || cause,
      })
      .where(eq(callSessions.id, sessionId));

    await db.insert(callLogs).values({
      callSessionId: sessionId,
      eventType: "hangup",
      eventData: { cause, details },
    });
  }

  /**
   * Handle error during call
   */
  static async handleError(sessionId: number, error: string): Promise<void> {
    const db = getDb();

    await db.insert(callLogs).values({
      callSessionId: sessionId,
      eventType: "error",
      eventData: { error },
    });
  }
}
