import { authRouter } from "./auth-router";
import { createRouter, publicQuery } from "./middleware";
import { campaignRouter } from "./routers/campaign";
import { callRouter } from "./routers/call";
import { leadRouter } from "./routers/lead";
import { analyticsRouter } from "./routers/analytics";
import { avrAgentRouter } from "./routers/avr-agent";
import { vicidialRouter } from "./routers/vicidial";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  campaign: campaignRouter,
  call: callRouter,
  lead: leadRouter,
  analytics: analyticsRouter,
  avr: avrAgentRouter,
  vicidial: vicidialRouter,
});

export type AppRouter = typeof appRouter;
