import { z } from "zod";
import { eq, desc, and, sql, gte, lte } from "drizzle-orm";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { callSessions, questionAnswers, callLogs, campaigns, leads } from "@db/schema";

export const callRouter = createRouter({
  list: publicQuery
    .input(
      z
        .object({
          campaignId: z.number().optional(),
          status: z.string().optional(),
          dateFrom: z.string().optional(),
          dateTo: z.string().optional(),
          search: z.string().optional(),
          limit: z.number().min(1).max(100).default(50),
          offset: z.number().min(0).default(0),
        })
        .optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];
      if (input?.campaignId) conditions.push(eq(callSessions.campaignId, input.campaignId));
      if (input?.status) conditions.push(eq(callSessions.callStatus, input.status as any));
      if (input?.dateFrom) conditions.push(gte(callSessions.createdAt, new Date(input.dateFrom)));
      if (input?.dateTo) conditions.push(lte(callSessions.createdAt, new Date(input.dateTo)));

      const result = await db
        .select({
          id: callSessions.id,
          leadId: callSessions.leadId,
          campaignId: callSessions.campaignId,
          campaignName: campaigns.name,
          leadPhone: leads.phoneNumber,
          leadFirstName: leads.firstName,
          leadLastName: leads.lastName,
          callStatus: callSessions.callStatus,
          startedAt: callSessions.startedAt,
          connectedAt: callSessions.connectedAt,
          transferredAt: callSessions.transferredAt,
          endedAt: callSessions.endedAt,
          durationSeconds: callSessions.durationSeconds,
          transferSuccess: callSessions.transferSuccess,
          recordingUrl: callSessions.recordingUrl,
          hangupCause: callSessions.hangupCause,
          createdAt: callSessions.createdAt,
        })
        .from(callSessions)
        .leftJoin(campaigns, eq(callSessions.campaignId, campaigns.id))
        .leftJoin(leads, eq(callSessions.leadId, leads.id))
        .where(conditions.length > 0 ? and(...conditions) : undefined)
        .orderBy(desc(callSessions.createdAt))
        .limit(input?.limit || 50)
        .offset(input?.offset || 0);

      const countResult = await db
        .select({ count: sql<number>`COUNT(*)` })
        .from(callSessions)
        .where(conditions.length > 0 ? and(...conditions) : undefined);

      return { calls: result, total: countResult[0]?.count || 0 };
    }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [session] = await db
        .select({
          id: callSessions.id,
          leadId: callSessions.leadId,
          campaignId: callSessions.campaignId,
          campaignName: campaigns.name,
          leadPhone: leads.phoneNumber,
          leadFirstName: leads.firstName,
          leadLastName: leads.lastName,
          vicidialCallId: callSessions.vicidialCallId,
          callStatus: callSessions.callStatus,
          verifierId: callSessions.verifierId,
          startedAt: callSessions.startedAt,
          connectedAt: callSessions.connectedAt,
          transferredAt: callSessions.transferredAt,
          endedAt: callSessions.endedAt,
          durationSeconds: callSessions.durationSeconds,
          transferSuccess: callSessions.transferSuccess,
          recordingUrl: callSessions.recordingUrl,
          hangupCause: callSessions.hangupCause,
          createdAt: callSessions.createdAt,
        })
        .from(callSessions)
        .leftJoin(campaigns, eq(callSessions.campaignId, campaigns.id))
        .leftJoin(leads, eq(callSessions.leadId, leads.id))
        .where(eq(callSessions.id, input.id));

      if (!session) return null;

      const answers = await db
        .select()
        .from(questionAnswers)
        .where(eq(questionAnswers.callSessionId, input.id));

      const logs = await db
        .select()
        .from(callLogs)
        .where(eq(callLogs.callSessionId, input.id))
        .orderBy(callLogs.timestamp);

      return { ...session, answers, logs };
    }),

  getActive: publicQuery.query(async () => {
    const db = getDb();
    const result = await db
      .select({
        id: callSessions.id,
        leadId: callSessions.leadId,
        campaignId: callSessions.campaignId,
        campaignName: campaigns.name,
        leadPhone: leads.phoneNumber,
        leadFirstName: leads.firstName,
        leadLastName: leads.lastName,
        callStatus: callSessions.callStatus,
        startedAt: callSessions.startedAt,
        connectedAt: callSessions.connectedAt,
        durationSeconds: sql<number>`TIMESTAMPDIFF(SECOND, ${callSessions.startedAt}, NOW())`,
        transferSuccess: callSessions.transferSuccess,
        createdAt: callSessions.createdAt,
      })
      .from(callSessions)
      .leftJoin(campaigns, eq(callSessions.campaignId, campaigns.id))
      .leftJoin(leads, eq(callSessions.leadId, leads.id))
      .where(
        and(
          sql`${callSessions.callStatus} NOT IN ('completed', 'failed', 'busy', 'no_answer')`,
          sql`${callSessions.endedAt} IS NULL`
        )
      )
      .orderBy(desc(callSessions.startedAt));
    return result;
  }),

  updateStatus: publicQuery
    .input(
      z.object({
        id: z.number(),
        status: z.enum([
          "initiated",
          "connected",
          "qualifying_q1",
          "qualifying_q2",
          "qualifying_q3",
          "transferring",
          "transferred",
          "completed",
          "failed",
          "voicemail",
          "busy",
          "no_answer",
        ]),
        verifierId: z.number().optional(),
        recordingUrl: z.string().optional(),
        hangupCause: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, status, verifierId, recordingUrl, hangupCause } = input;
      const updateData: any = { callStatus: status };

      if (status === "connected") updateData.connectedAt = new Date();
      if (status === "transferred") updateData.transferredAt = new Date();
      if (["completed", "failed", "busy", "no_answer", "voicemail"].includes(status)) {
        updateData.endedAt = new Date();
        if (updateData.connectedAt) {
          updateData.durationSeconds = Math.floor(
            (new Date().getTime() - updateData.connectedAt.getTime()) / 1000
          );
        }
      }
      if (verifierId) updateData.verifierId = verifierId;
      if (recordingUrl) updateData.recordingUrl = recordingUrl;
      if (hangupCause) updateData.hangupCause = hangupCause;
      if (status === "transferred") updateData.transferSuccess = true;

      await db.update(callSessions).set(updateData).where(eq(callSessions.id, id));
      return { success: true };
    }),

  handleWebhook: publicQuery
    .input(
      z.object({
        event: z.enum([
          "dial",
          "connect",
          "tts_greeting",
          "ask_q1",
          "listen_q1",
          "ask_q2",
          "listen_q2",
          "ask_q3",
          "listen_q3",
          "announce_transfer",
          "initiate_3way",
          "bridge_confirmed",
          "ai_dropoff",
          "verifier_join",
          "hangup",
          "error",
        ]),
        callSessionId: z.number(),
        eventData: z.any().optional(),
        mossAudioUrl: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.insert(callLogs).values({
        callSessionId: input.callSessionId,
        eventType: input.event,
        eventData: input.eventData || null,
        mossAudioUrl: input.mossAudioUrl || null,
      });
      return { success: true };
    }),

  saveAnswer: publicQuery
    .input(
      z.object({
        callSessionId: z.number(),
        questionId: z.number(),
        questionText: z.string(),
        transcribedAnswer: z.string(),
        confidenceScore: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.insert(questionAnswers).values({
        callSessionId: input.callSessionId,
        questionId: input.questionId,
        questionText: input.questionText,
        transcribedAnswer: input.transcribedAnswer,
        confidenceScore: input.confidenceScore ? String(input.confidenceScore) : null,
        answeredAt: new Date(),
      });
      return { success: true };
    }),
});
