import { z } from "zod";
import { eq } from "drizzle-orm";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { campaigns, callSessions, verifiers } from "@db/schema";

export const avrAgentRouter = createRouter({
  getConfig: publicQuery
    .input(z.object({ campaignId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [campaign] = await db
        .select()
        .from(campaigns)
        .where(eq(campaigns.id, input.campaignId));
      return campaign || null;
    }),

  synthesize: publicQuery
    .input(
      z.object({
        text: z.string().min(1),
        voiceId: z.string().optional(),
        speed: z.number().optional(),
        pitch: z.number().optional(),
        language: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const mossTtsUrl = process.env.MOSS_TTS_URL || "http://localhost:8080";
      try {
        const response = await fetch(`${mossTtsUrl}/synthesize`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            text: input.text,
            voice_id: input.voiceId || "en-US-female-1",
            speed: input.speed || 1.0,
            pitch: input.pitch || 1.0,
            language: input.language || "en-US",
            format: "ulaw",
            sample_rate: 8000,
          }),
        });

        if (!response.ok) {
          throw new Error(`MOSS-TTS error: ${response.statusText}`);
        }

        const audioBuffer = await response.arrayBuffer();
        return {
          success: true,
          audio: Buffer.from(audioBuffer).toString("base64"),
          format: "ulaw",
          sampleRate: 8000,
        };
      } catch (error: any) {
        return {
          success: false,
          error: error.message || "TTS synthesis failed",
        };
      }
    }),

  getVoices: publicQuery.query(async () => {
    const mossTtsUrl = process.env.MOSS_TTS_URL || "http://localhost:8080";
    try {
      const response = await fetch(`${mossTtsUrl}/voices`, {
        method: "GET",
        headers: { "Content-Type": "application/json" },
      });
      if (!response.ok) throw new Error("Failed to fetch voices");
      const voices = await response.json();
      return voices;
    } catch {
      return [
        { id: "en-US-female-1", name: "English US Female", language: "en-US", gender: "female" },
        { id: "en-US-male-1", name: "English US Male", language: "en-US", gender: "male" },
        { id: "es-ES-female-1", name: "Spanish Female", language: "es-ES", gender: "female" },
        { id: "hi-IN-female-1", name: "Hindi Female", language: "hi-IN", gender: "female" },
      ];
    }
  }),

  handleCallEvent: publicQuery
    .input(
      z.object({
        event: z.enum([
          "call_started",
          "greeting_played",
          "question_asked",
          "answer_received",
          "transfer_initiated",
          "transfer_confirmed",
          "ai_disconnected",
          "error",
        ]),
        sessionId: z.number(),
        data: z.any().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const statusMap: Record<string, string> = {
        call_started: "connected",
        greeting_played: "connected",
        question_asked: "qualifying_q1",
        answer_received: "qualifying_q2",
        transfer_initiated: "transferring",
        transfer_confirmed: "transferred",
        ai_disconnected: "completed",
        error: "failed",
      };

      const newStatus = statusMap[input.event];
      if (newStatus) {
        await db
          .update(callSessions)
          .set({
            callStatus: newStatus as any,
            ...(input.event === "transfer_confirmed"
              ? { transferSuccess: true, transferredAt: new Date() }
              : {}),
            ...(input.event === "ai_disconnected" ? { endedAt: new Date() } : {}),
            updatedAt: new Date(),
          })
          .where(eq(callSessions.id, input.sessionId));
      }

      return { success: true, status: newStatus };
    }),

  getVerifierQueue: publicQuery
    .input(z.object({ ingroup: z.string().optional() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db
        .select()
        .from(verifiers)
        .where(
          input?.ingroup
            ? eq(verifiers.status, "online")
            : undefined
        )
        .orderBy(verifiers.currentCalls);
      return result;
    }),
});
