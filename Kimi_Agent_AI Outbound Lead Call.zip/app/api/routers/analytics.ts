import { z } from "zod";
import { eq, desc, and, sql, gte, lte } from "drizzle-orm";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { callSessions, campaigns, questionAnswers, verifiers } from "@db/schema";

export const analyticsRouter = createRouter({
  getDashboard: publicQuery
    .input(
      z
        .object({
          dateFrom: z.string().optional(),
          dateTo: z.string().optional(),
        })
        .optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];
      if (input?.dateFrom) conditions.push(gte(callSessions.createdAt, new Date(input.dateFrom)));
      if (input?.dateTo) conditions.push(lte(callSessions.createdAt, new Date(input.dateTo)));

      const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

      const overallStats = await db
        .select({
          totalCalls: sql<number>`COUNT(*)`,
          connected: sql<number>`SUM(CASE WHEN call_status IN ('connected','qualifying_q1','qualifying_q2','qualifying_q3','transferring','transferred','completed') THEN 1 ELSE 0 END)`,
          transferred: sql<number>`SUM(CASE WHEN call_status IN ('transferred','completed') THEN 1 ELSE 0 END)`,
          completed: sql<number>`SUM(CASE WHEN call_status = 'completed' THEN 1 ELSE 0 END)`,
          failed: sql<number>`SUM(CASE WHEN call_status IN ('failed','busy','no_answer','voicemail') THEN 1 ELSE 0 END)`,
          avgDuration: sql<number>`COALESCE(AVG(duration_seconds), 0)`,
        })
        .from(callSessions)
        .where(whereClause);

      const campaignPerf = await db
        .select({
          campaignId: callSessions.campaignId,
          campaignName: campaigns.name,
          totalCalls: sql<number>`COUNT(*)`,
          connected: sql<number>`SUM(CASE WHEN call_status IN ('connected','qualifying_q1','qualifying_q2','qualifying_q3','transferring','transferred','completed') THEN 1 ELSE 0 END)`,
          transferred: sql<number>`SUM(CASE WHEN call_status IN ('transferred','completed') THEN 1 ELSE 0 END)`,
          completed: sql<number>`SUM(CASE WHEN call_status = 'completed' THEN 1 ELSE 0 END)`,
        })
        .from(callSessions)
        .leftJoin(campaigns, eq(callSessions.campaignId, campaigns.id))
        .where(whereClause)
        .groupBy(callSessions.campaignId)
        .orderBy(desc(sql`COUNT(*)`));

      const dailyStats = await db
        .select({
          date: sql<string>`DATE(${callSessions.createdAt})`,
          totalCalls: sql<number>`COUNT(*)`,
          connected: sql<number>`SUM(CASE WHEN call_status IN ('connected','qualifying_q1','qualifying_q2','qualifying_q3','transferring','transferred','completed') THEN 1 ELSE 0 END)`,
          transferred: sql<number>`SUM(CASE WHEN call_status IN ('transferred','completed') THEN 1 ELSE 0 END)`,
          completed: sql<number>`SUM(CASE WHEN call_status = 'completed' THEN 1 ELSE 0 END)`,
        })
        .from(callSessions)
        .where(whereClause)
        .groupBy(sql`DATE(${callSessions.createdAt})`)
        .orderBy(sql`DATE(${callSessions.createdAt})`);

      const activeNow = await db
        .select({ count: sql<number>`COUNT(*)` })
        .from(callSessions)
        .where(
          and(
            sql`${callSessions.callStatus} NOT IN ('completed', 'failed', 'busy', 'no_answer')`,
            sql`${callSessions.endedAt} IS NULL`
          )
        );

      return {
        overall: overallStats[0],
        activeNow: activeNow[0]?.count || 0,
        campaignPerf: campaignPerf.slice(0, 10),
        dailyStats: dailyStats.slice(-30),
      };
    }),

  getFunnel: publicQuery
    .input(
      z
        .object({
          campaignId: z.number().optional(),
          dateFrom: z.string().optional(),
          dateTo: z.string().optional(),
        })
        .optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];
      if (input?.campaignId) conditions.push(eq(callSessions.campaignId, input.campaignId));
      if (input?.dateFrom) conditions.push(gte(callSessions.createdAt, new Date(input.dateFrom)));
      if (input?.dateTo) conditions.push(lte(callSessions.createdAt, new Date(input.dateTo)));

      const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

      const result = await db
        .select({
          totalDialed: sql<number>`COUNT(*)`,
          connected: sql<number>`SUM(CASE WHEN call_status IN ('connected','qualifying_q1','qualifying_q2','qualifying_q3','transferring','transferred','completed') THEN 1 ELSE 0 END)`,
          answeredQ1: sql<number>`SUM(CASE WHEN call_status IN ('qualifying_q2','qualifying_q3','transferring','transferred','completed') THEN 1 ELSE 0 END)`,
          answeredQ2: sql<number>`SUM(CASE WHEN call_status IN ('qualifying_q3','transferring','transferred','completed') THEN 1 ELSE 0 END)`,
          answeredQ3: sql<number>`SUM(CASE WHEN call_status IN ('transferring','transferred','completed') THEN 1 ELSE 0 END)`,
          transferred: sql<number>`SUM(CASE WHEN call_status IN ('transferred','completed') THEN 1 ELSE 0 END)`,
          completed: sql<number>`SUM(CASE WHEN call_status = 'completed' THEN 1 ELSE 0 END)`,
        })
        .from(callSessions)
        .where(whereClause);

      return result[0];
    }),

  getCampaignPerf: publicQuery
    .input(
      z
        .object({
          dateFrom: z.string().optional(),
          dateTo: z.string().optional(),
        })
        .optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];
      if (input?.dateFrom) conditions.push(gte(callSessions.createdAt, new Date(input.dateFrom)));
      if (input?.dateTo) conditions.push(lte(callSessions.createdAt, new Date(input.dateTo)));

      const result = await db
        .select({
          campaignId: callSessions.campaignId,
          campaignName: campaigns.name,
          status: campaigns.status,
          totalCalls: sql<number>`COUNT(*)`,
          connectedRate: sql<number>`ROUND(SUM(CASE WHEN call_status IN ('connected','qualifying_q1','qualifying_q2','qualifying_q3','transferring','transferred','completed') THEN 1 ELSE 0 END) / COUNT(*) * 100, 2)`,
          transferRate: sql<number>`ROUND(SUM(CASE WHEN call_status IN ('transferred','completed') THEN 1 ELSE 0 END) / COUNT(*) * 100, 2)`,
          completionRate: sql<number>`ROUND(SUM(CASE WHEN call_status = 'completed' THEN 1 ELSE 0 END) / COUNT(*) * 100, 2)`,
          avgDuration: sql<number>`COALESCE(AVG(duration_seconds), 0)`,
        })
        .from(callSessions)
        .leftJoin(campaigns, eq(callSessions.campaignId, campaigns.id))
        .where(conditions.length > 0 ? and(...conditions) : undefined)
        .groupBy(callSessions.campaignId)
        .orderBy(desc(sql`COUNT(*)`));

      return result;
    }),

  getVerifierPerf: publicQuery
    .input(
      z
        .object({
          dateFrom: z.string().optional(),
          dateTo: z.string().optional(),
        })
        .optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];
      if (input?.dateFrom) conditions.push(gte(callSessions.createdAt, new Date(input.dateFrom)));
      if (input?.dateTo) conditions.push(lte(callSessions.createdAt, new Date(input.dateTo)));
      conditions.push(eq(callSessions.transferSuccess, true));

      const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

      const result = await db
        .select({
          verifierId: callSessions.verifierId,
          verifierName: verifiers.name,
          totalHandled: sql<number>`COUNT(*)`,
          avgDuration: sql<number>`COALESCE(AVG(duration_seconds), 0)`,
        })
        .from(callSessions)
        .leftJoin(verifiers, eq(callSessions.verifierId, verifiers.id))
        .where(whereClause)
        .groupBy(callSessions.verifierId)
        .orderBy(desc(sql`COUNT(*)`));

      return result;
    }),

  getQuestionAnalytics: publicQuery
    .input(
      z.object({
        campaignId: z.number(),
        dateFrom: z.string().optional(),
        dateTo: z.string().optional(),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [eq(questionAnswers.questionId, input.campaignId)];

      const result = await db
        .select({
          questionText: questionAnswers.questionText,
          totalAnswers: sql<number>`COUNT(*)`,
          yesCount: sql<number>`SUM(CASE WHEN LOWER(transcribed_answer) IN ('yes','yeah','yep','sure','correct','right') THEN 1 ELSE 0 END)`,
          noCount: sql<number>`SUM(CASE WHEN LOWER(transcribed_answer) IN ('no','nope','nah','not','dont') THEN 1 ELSE 0 END)`,
          avgConfidence: sql<number>`COALESCE(AVG(confidence_score), 0)`,
        })
        .from(questionAnswers)
        .where(and(...conditions))
        .groupBy(questionAnswers.questionText);

      return result;
    }),
});
