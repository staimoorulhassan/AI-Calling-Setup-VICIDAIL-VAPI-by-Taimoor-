import { z } from "zod";
import { eq, desc, and, sql } from "drizzle-orm";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { leads, campaigns } from "@db/schema";

export const leadRouter = createRouter({
  list: publicQuery
    .input(
      z
        .object({
          campaignId: z.number().optional(),
          status: z.string().optional(),
          search: z.string().optional(),
          limit: z.number().min(1).max(100).default(50),
          offset: z.number().min(0).default(0),
        })
        .optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];
      if (input?.campaignId) conditions.push(eq(leads.campaignId, input.campaignId));
      if (input?.status) conditions.push(eq(leads.status, input.status as any));
      if (input?.search) {
        conditions.push(
          sql`(${leads.firstName} LIKE ${`%${input.search}%`} OR ${leads.lastName} LIKE ${`%${input.search}%`} OR ${leads.phoneNumber} LIKE ${`%${input.search}%`})`
        );
      }

      const result = await db
        .select({
          id: leads.id,
          phoneNumber: leads.phoneNumber,
          firstName: leads.firstName,
          lastName: leads.lastName,
          email: leads.email,
          vicidialLeadId: leads.vicidialLeadId,
          listId: leads.listId,
          campaignId: leads.campaignId,
          campaignName: campaigns.name,
          status: leads.status,
          customFields: leads.customFields,
          createdAt: leads.createdAt,
          updatedAt: leads.updatedAt,
          callCount: sql<number>`COALESCE((SELECT COUNT(*) FROM call_sessions WHERE call_sessions.lead_id = ${leads.id}), 0)`,
        })
        .from(leads)
        .leftJoin(campaigns, eq(leads.campaignId, campaigns.id))
        .where(conditions.length > 0 ? and(...conditions) : undefined)
        .orderBy(desc(leads.createdAt))
        .limit(input?.limit || 50)
        .offset(input?.offset || 0);

      const countResult = await db
        .select({ count: sql<number>`COUNT(*)` })
        .from(leads)
        .where(conditions.length > 0 ? and(...conditions) : undefined);

      return { leads: result, total: countResult[0]?.count || 0 };
    }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [lead] = await db
        .select({
          id: leads.id,
          phoneNumber: leads.phoneNumber,
          firstName: leads.firstName,
          lastName: leads.lastName,
          email: leads.email,
          vicidialLeadId: leads.vicidialLeadId,
          listId: leads.listId,
          campaignId: leads.campaignId,
          campaignName: campaigns.name,
          status: leads.status,
          customFields: leads.customFields,
          createdAt: leads.createdAt,
          updatedAt: leads.updatedAt,
        })
        .from(leads)
        .leftJoin(campaigns, eq(leads.campaignId, campaigns.id))
        .where(eq(leads.id, input.id));
      return lead || null;
    }),

  import: publicQuery
    .input(
      z.object({
        campaignId: z.number(),
        leads: z.array(
          z.object({
            phoneNumber: z.string().min(1).max(20),
            firstName: z.string().optional(),
            lastName: z.string().optional(),
            email: z.string().email().optional(),
            vicidialLeadId: z.string().optional(),
            listId: z.string().optional(),
            customFields: z.any().optional(),
          })
        ),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const result = await db.insert(leads).values(
        input.leads.map((l) => ({
          phoneNumber: l.phoneNumber,
          firstName: l.firstName || null,
          lastName: l.lastName || null,
          email: l.email || null,
          vicidialLeadId: l.vicidialLeadId || null,
          listId: l.listId || null,
          campaignId: input.campaignId,
          status: "new" as const,
          customFields: l.customFields || null,
        }))
      );
      const insertId = (result as any).insertId ? Number((result as any).insertId) : 0;
      return { imported: input.leads.length, insertId };
    }),

  updateStatus: publicQuery
    .input(
      z.object({
        id: z.number(),
        status: z.enum([
          "new",
          "dialed",
          "connected",
          "qualified",
          "not_qualified",
          "not_interested",
          "dnc",
          "converted",
        ]),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .update(leads)
        .set({ status: input.status, updatedAt: new Date() })
        .where(eq(leads.id, input.id));
      return { success: true };
    }),

  getStats: publicQuery
    .input(z.object({ campaignId: z.number().optional() }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];
      if (input?.campaignId) conditions.push(eq(leads.campaignId, input.campaignId));

      const result = await db
        .select({
          total: sql<number>`COUNT(*)`,
          new: sql<number>`SUM(CASE WHEN status = 'new' THEN 1 ELSE 0 END)`,
          dialed: sql<number>`SUM(CASE WHEN status = 'dialed' THEN 1 ELSE 0 END)`,
          connected: sql<number>`SUM(CASE WHEN status = 'connected' THEN 1 ELSE 0 END)`,
          qualified: sql<number>`SUM(CASE WHEN status = 'qualified' THEN 1 ELSE 0 END)`,
          notQualified: sql<number>`SUM(CASE WHEN status = 'not_qualified' THEN 1 ELSE 0 END)`,
          notInterested: sql<number>`SUM(CASE WHEN status = 'not_interested' THEN 1 ELSE 0 END)`,
          converted: sql<number>`SUM(CASE WHEN status = 'converted' THEN 1 ELSE 0 END)`,
          dnc: sql<number>`SUM(CASE WHEN status = 'dnc' THEN 1 ELSE 0 END)`,
        })
        .from(leads)
        .where(conditions.length > 0 ? and(...conditions) : undefined);
      return result[0];
    }),
});
