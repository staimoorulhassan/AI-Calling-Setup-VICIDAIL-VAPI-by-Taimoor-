import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";

// Vicidial configuration from environment
const VICIDIAL_URL = process.env.VICIDIAL_URL || "";
const VICIDIAL_API_KEY = process.env.VICIDIAL_API_KEY || "";
const VICIDIAL_USER = process.env.VICIDIAL_USER || "";
const AMI_HOST = process.env.AMI_HOST || "";
const AMI_PORT = parseInt(process.env.AMI_PORT || "5038");
const AMI_USERNAME = process.env.AMI_USERNAME || "";
const AMI_SECRET = process.env.AMI_SECRET || "";

// Simple AMI action sender using TCP
async function sendAmiAction(action: Record<string, string>): Promise<any> {
  const net = await import("net");
  return new Promise((resolve, reject) => {
    const client = new net.Socket();
    let buffer = "";

    client.connect(AMI_PORT, AMI_HOST, () => {
      let actionStr = "";
      for (const [key, value] of Object.entries(action)) {
        actionStr += `${key}: ${value}\r\n`;
      }
      actionStr += "\r\n";

      // Login first
      client.write(
        `Action: Login\r\nUsername: ${AMI_USERNAME}\r\nSecret: ${AMI_SECRET}\r\n\r\n`
      );

      // Wait for login response then send actual action
      const onData = (data: Buffer) => {
        buffer += data.toString();
        if (buffer.includes("Authentication accepted")) {
          client.removeListener("data", onData);
          client.write(actionStr);
          buffer = "";
        }
        if (buffer.includes("Response: Success") || buffer.includes("Response: Error")) {
          client.destroy();
          resolve(buffer);
        }
      };
      client.on("data", onData);
    });

    client.setTimeout(10000, () => {
      client.destroy();
      reject(new Error("AMI connection timeout"));
    });

    client.on("error", (err) => {
      reject(err);
    });
  });
}

export const vicidialRouter = createRouter({
  getCampaigns: publicQuery.query(async () => {
    if (!VICIDIAL_URL) {
      return [
        { campaignId: "DEMO-1", campaignName: "Demo Outbound Campaign 1", status: "ACTIVE" },
        { campaignId: "DEMO-2", campaignName: "Demo Outbound Campaign 2", status: "ACTIVE" },
      ];
    }
    try {
      const response = await fetch(
        `${VICIDIAL_URL}/non_agent_api.php?function=campaigns&user=${VICIDIAL_USER}&api_key=${VICIDIAL_API_KEY}`
      );
      if (!response.ok) throw new Error("Failed to fetch campaigns");
      const data = await response.json();
      return data;
    } catch (error: any) {
      return { error: error.message };
    }
  }),

  getLists: publicQuery
    .input(z.object({ campaignId: z.string() }).optional())
    .query(async ({ input }) => {
      if (!VICIDIAL_URL) {
        return [
          { listId: "LIST-1", listName: "Lead List 1", campaignId: input?.campaignId || "DEMO-1" },
          { listId: "LIST-2", listName: "Lead List 2", campaignId: input?.campaignId || "DEMO-1" },
        ];
      }
      try {
        const url = input?.campaignId
          ? `${VICIDIAL_URL}/non_agent_api.php?function=lists&campaign_id=${input.campaignId}&user=${VICIDIAL_USER}&api_key=${VICIDIAL_API_KEY}`
          : `${VICIDIAL_URL}/non_agent_api.php?function=lists&user=${VICIDIAL_USER}&api_key=${VICIDIAL_API_KEY}`;
        const response = await fetch(url);
        if (!response.ok) throw new Error("Failed to fetch lists");
        return await response.json();
      } catch (error: any) {
        return { error: error.message };
      }
    }),

  transferCall: publicQuery
    .input(
      z.object({
        channel: z.string().min(1),
        destination: z.string().min(1),
        context: z.string().default("from-internal"),
        callerId: z.string().optional(),
        variables: z.record(z.string(), z.string()).optional(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const action: Record<string, string> = {
          Action: "Originate",
          Channel: input.channel,
          Exten: input.destination,
          Context: input.context,
          Priority: "1",
          Async: "true",
        };
        if (input.callerId) action["CallerID"] = input.callerId;
        if (input.variables) {
          action["Variable"] = Object.entries(input.variables)
            .map(([k, v]) => `${k}=${v}`)
            .join("|");
        }

        const result = await sendAmiAction(action);
        return { success: true, result };
      } catch (error: any) {
        return { success: false, error: error.message };
      }
    }),

  setDisposition: publicQuery
    .input(
      z.object({
        leadId: z.string().min(1),
        callId: z.string().optional(),
        status: z.string().min(1),
        user: z.string().optional(),
        campaignId: z.string().optional(),
        comments: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      if (!VICIDIAL_URL) {
        return { success: true, message: "Mock: Disposition set", mock: true };
      }
      try {
        const params = new URLSearchParams({
          function: "update_lead",
          lead_id: input.leadId,
          status: input.status,
          user: input.user || VICIDIAL_USER,
          api_key: VICIDIAL_API_KEY,
        });
        if (input.callId) params.append("call_id", input.callId);
        if (input.campaignId) params.append("campaign_id", input.campaignId);
        if (input.comments) params.append("comments", input.comments);

        const response = await fetch(`${VICIDIAL_URL}/non_agent_api.php?${params.toString()}`);
        if (!response.ok) throw new Error("Failed to set disposition");
        return await response.json();
      } catch (error: any) {
        return { success: false, error: error.message };
      }
    }),

  getAgents: publicQuery.query(async () => {
    if (!VICIDIAL_URL) {
      return [
        { user: "VERIFIER-1", fullName: "John Smith", extension: "8001", status: "ACTIVE" },
        { user: "VERIFIER-2", fullName: "Jane Doe", extension: "8002", status: "ACTIVE" },
        { user: "VERIFIER-3", fullName: "Bob Wilson", extension: "8003", status: "PAUSED" },
      ];
    }
    try {
      const response = await fetch(
        `${VICIDIAL_URL}/non_agent_api.php?function=agents&user=${VICIDIAL_USER}&api_key=${VICIDIAL_API_KEY}`
      );
      if (!response.ok) throw new Error("Failed to fetch agents");
      return await response.json();
    } catch (error: any) {
      return { error: error.message };
    }
  }),

  // Bridge two channels for 3-way conference
  bridgeChannels: publicQuery
    .input(
      z.object({
        channel1: z.string().min(1),
        channel2: z.string().min(1),
        tone: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const action: Record<string, string> = {
          Action: "Bridge",
          Channel1: input.channel1,
          Channel2: input.channel2,
          Tone: input.tone || "Yes",
        };

        const result = await sendAmiAction(action);
        return { success: true, result };
      } catch (error: any) {
        return { success: false, error: error.message };
      }
    }),

  // Redirect a channel to a new extension/context
  redirectChannel: publicQuery
    .input(
      z.object({
        channel: z.string().min(1),
        context: z.string().min(1),
        exten: z.string().min(1),
        priority: z.string().default("1"),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const action: Record<string, string> = {
          Action: "Redirect",
          Channel: input.channel,
          Context: input.context,
          Exten: input.exten,
          Priority: input.priority,
        };

        const result = await sendAmiAction(action);
        return { success: true, result };
      } catch (error: any) {
        return { success: false, error: error.message };
      }
    }),
});
