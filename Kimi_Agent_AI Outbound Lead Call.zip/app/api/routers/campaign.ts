import { z } from "zod";
import { eq, desc, and, sql } from "drizzle-orm";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { campaigns, qualifyingQuestions } from "@db/schema";

export const campaignRouter = createRouter({
  list: publicQuery
    .input(
      z
        .object({
          status: z.enum(["active", "inactive", "paused"]).optional(),
          search: z.string().optional(),
        })
        .optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];
      if (input?.status) conditions.push(eq(campaigns.status, input.status));
      const result = await db
        .select({
          id: campaigns.id,
          name: campaigns.name,
          vicidialCampaignId: campaigns.vicidialCampaignId,
          status: campaigns.status,
          language: campaigns.language,
          mossVoiceId: campaigns.mossVoiceId,
          verifierIngroup: campaigns.verifierIngroup,
          createdAt: campaigns.createdAt,
          updatedAt: campaigns.updatedAt,
          totalCalls: sql<number>`COALESCE((SELECT COUNT(*) FROM call_sessions WHERE call_sessions.campaign_id = ${campaigns.id}), 0)`,
          transferredCalls: sql<number>`COALESCE((SELECT COUNT(*) FROM call_sessions WHERE call_sessions.campaign_id = ${campaigns.id} AND call_sessions.transfer_success = 1), 0)`,
        })
        .from(campaigns)
        .where(conditions.length > 0 ? and(...conditions) : undefined)
        .orderBy(desc(campaigns.createdAt));
      return result;
    }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [campaign] = await db
        .select()
        .from(campaigns)
        .where(eq(campaigns.id, input.id));
      if (!campaign) return null;

      const questions = await db
        .select()
        .from(qualifyingQuestions)
        .where(eq(qualifyingQuestions.campaignId, input.id))
        .orderBy(qualifyingQuestions.questionOrder);

      return { ...campaign, questions };
    }),

  create: publicQuery
    .input(
      z.object({
        name: z.string().min(1).max(255),
        vicidialCampaignId: z.string().min(1).max(50),
        greetingMessage: z.string().min(1),
        closingMessage: z.string().optional(),
        transferMessage: z.string().optional(),
        mossVoiceId: z.string().min(1).max(100),
        language: z.string().default("en-US"),
        ttsSpeed: z.string().default("1.00"),
        ttsPitch: z.string().default("1.00"),
        verifierIngroup: z.string().min(1).max(100),
        verifierExtension: z.string().optional(),
        questions: z
          .array(
            z.object({
              questionText: z.string().min(1),
              expectedAnswerType: z.enum(["yes_no", "numeric", "text", "choice"]).default("text"),
              validationRules: z.any().optional(),
              isRequired: z.boolean().default(true),
            })
          )
          .length(3, "Exactly 3 qualifying questions are required"),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const [campaign] = await db.insert(campaigns).values({
        name: input.name,
        vicidialCampaignId: input.vicidialCampaignId,
        status: "active",
        greetingMessage: input.greetingMessage,
        closingMessage: input.closingMessage || null,
        transferMessage: input.transferMessage || null,
        mossVoiceId: input.mossVoiceId,
        language: input.language,
        ttsSpeed: input.ttsSpeed,
        ttsPitch: input.ttsPitch,
        verifierIngroup: input.verifierIngroup,
        verifierExtension: input.verifierExtension || null,
      });

      const campaignId = Number(campaign.insertId);

      await db.insert(qualifyingQuestions).values(
        input.questions.map((q, idx) => ({
          campaignId,
          questionOrder: idx + 1,
          questionText: q.questionText,
          expectedAnswerType: q.expectedAnswerType,
          validationRules: q.validationRules || null,
          isRequired: q.isRequired,
        }))
      );

      return { id: campaignId };
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        name: z.string().min(1).max(255).optional(),
        status: z.enum(["active", "inactive", "paused"]).optional(),
        greetingMessage: z.string().optional(),
        closingMessage: z.string().optional(),
        transferMessage: z.string().optional(),
        mossVoiceId: z.string().optional(),
        language: z.string().optional(),
        ttsSpeed: z.string().optional(),
        ttsPitch: z.string().optional(),
        verifierIngroup: z.string().optional(),
        verifierExtension: z.string().optional(),
        questions: z
          .array(
            z.object({
              questionText: z.string().min(1),
              expectedAnswerType: z.enum(["yes_no", "numeric", "text", "choice"]).default("text"),
              validationRules: z.any().optional(),
              isRequired: z.boolean().default(true),
            })
          )
          .length(3)
          .optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, questions, ...updateData } = input;

      await db
        .update(campaigns)
        .set({
          ...updateData,
          updatedAt: new Date(),
        })
        .where(eq(campaigns.id, id));

      if (questions) {
        await db
          .delete(qualifyingQuestions)
          .where(eq(qualifyingQuestions.campaignId, id));

        await db.insert(qualifyingQuestions).values(
          questions.map((q, idx) => ({
            campaignId: id,
            questionOrder: idx + 1,
            questionText: q.questionText,
            expectedAnswerType: q.expectedAnswerType,
            validationRules: q.validationRules || null,
            isRequired: q.isRequired,
          }))
        );
      }

      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .update(campaigns)
        .set({ status: "inactive" })
        .where(eq(campaigns.id, input.id));
      return { success: true };
    }),

  getStats: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db
        .select({
          totalCalls: sql<number>`COUNT(*)`,
          connected: sql<number>`SUM(CASE WHEN call_status IN ('connected','qualifying_q1','qualifying_q2','qualifying_q3','transferring','transferred','completed') THEN 1 ELSE 0 END)`,
          qualified: sql<number>`SUM(CASE WHEN call_status IN ('qualifying_q2','qualifying_q3','transferring','transferred','completed') THEN 1 ELSE 0 END)`,
          transferred: sql<number>`SUM(CASE WHEN call_status IN ('transferred','completed') THEN 1 ELSE 0 END)`,
          completed: sql<number>`SUM(CASE WHEN call_status = 'completed' THEN 1 ELSE 0 END)`,
          failed: sql<number>`SUM(CASE WHEN call_status IN ('failed','busy','no_answer','voicemail') THEN 1 ELSE 0 END)`,
          avgDuration: sql<number>`AVG(duration_seconds)`,
        })
        .from(callSessions)
        .where(eq(callSessions.campaignId, input.id));
      return result[0];
    }),
});

// Need this import here for the stats query
import { callSessions } from "@db/schema";
