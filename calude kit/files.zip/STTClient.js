'use strict';
/**
 * src/stt/STTClient.js
 *
 * Streams ulaw 8kHz audio to Deepgram (or Whisper) in real-time.
 * Emits:
 *   'transcript'  → string  (final recognised utterance)
 *   'interim'     → string  (partial, for logging only)
 *   'silence'     → void    (no speech detected for SILENCE_TIMEOUT_MS)
 *
 * Spec: specs/system.spec.yaml → stt
 */

const WebSocket  = require('ws');
const EventEmitter = require('events');
const logger     = require('../utils/logger');

const PROVIDER          = process.env.STT_PROVIDER  || 'deepgram';
const API_KEY           = process.env.STT_API_KEY   || '';
const SAMPLE_RATE       = 8000;
const ENCODING          = 'mulaw';
const SILENCE_TIMEOUT   = parseInt(process.env.QUESTION_TIMEOUT_MS || '6000', 10);
const DEEPGRAM_WS_URL   = `wss://api.deepgram.com/v1/listen?encoding=${ENCODING}&sample_rate=${SAMPLE_RATE}&model=nova-2-phonecall&endpointing=500`;

class STTClient extends EventEmitter {
  constructor() {
    super();
    this._ws           = null;
    this._silenceTimer = null;
    this._lastSpeech   = Date.now();
    this._buffer       = [];
    this._ready        = false;
  }

  start() {
    this._connect();
  }

  stop() {
    this._clearSilenceTimer();
    if (this._ws) { try { this._ws.close(); } catch (_) {} }
    this._ws = null;
  }

  /**
   * Feed raw ulaw audio frames (160 bytes = 20ms).
   */
  feed(buffer) {
    if (!this._ws || this._ws.readyState !== WebSocket.OPEN) {
      this._buffer.push(buffer);
      return;
    }
    // Drain any buffered frames first
    if (this._buffer.length) {
      this._buffer.forEach(b => this._ws.send(b));
      this._buffer = [];
    }
    this._ws.send(buffer);
  }

  // ── Internals ─────────────────────────────────────────────
  _connect() {
    const wsUrl = PROVIDER === 'deepgram' ? DEEPGRAM_WS_URL : this._whisperUrl();

    this._ws = new WebSocket(wsUrl, {
      headers: PROVIDER === 'deepgram' ? { Authorization: `Token ${API_KEY}` } : {},
    });

    this._ws.on('open', () => {
      this._ready = true;
      this._resetSilenceTimer();
      logger.info({ event: 'stt_connected', provider: PROVIDER });
    });

    this._ws.on('message', (data) => {
      try {
        const msg = JSON.parse(data);
        this._handleDeepgramMessage(msg);
      } catch (_) {}
    });

    this._ws.on('error', (err) => logger.error({ event: 'stt_error', error: err.message }));
    this._ws.on('close', () => { this._ready = false; });
  }

  _handleDeepgramMessage(msg) {
    const alt = msg?.channel?.alternatives?.[0];
    if (!alt) return;

    const text     = alt.transcript || '';
    const isFinal  = msg.is_final;

    if (!text) return;

    this._lastSpeech = Date.now();
    this._resetSilenceTimer();

    if (isFinal) {
      logger.info({ event: 'transcript_final', text });
      this.emit('transcript', text);
    } else {
      this.emit('interim', text);
    }
  }

  _resetSilenceTimer() {
    this._clearSilenceTimer();
    this._silenceTimer = setTimeout(() => {
      logger.info({ event: 'silence_detected' });
      this.emit('silence');
    }, SILENCE_TIMEOUT);
  }

  _clearSilenceTimer() {
    if (this._silenceTimer) { clearTimeout(this._silenceTimer); this._silenceTimer = null; }
  }

  _whisperUrl() {
    // Local Whisper WebSocket server (e.g. faster-whisper-server)
    return process.env.WHISPER_WS_URL || 'ws://localhost:9090/asr';
  }
}

module.exports = STTClient;
