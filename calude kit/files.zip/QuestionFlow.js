'use strict';
/**
 * src/session/QuestionFlow.js
 *
 * Loads questions.spec.yaml and provides:
 *  - currentPrompt(state, answers, meta)  → text to speak
 *  - classify(transcript, state)           → intent string
 *  - processIntent(intent, state, answers) → { nextState, disqualify }
 *  - onSilence(state)                      → { reprompt, transferAnyway }
 *
 * Spec: specs/questions.spec.yaml
 */

const fs   = require('fs');
const path = require('path');
const yaml = require('js-yaml');

const STATE = {
  GREETING    : 'GREETING',
  QUESTION_1  : 'QUESTION_1',
  QUESTION_2  : 'QUESTION_2',
  QUESTION_3  : 'QUESTION_3',
  TRANSFERRING: 'TRANSFERRING',
  AI_LEAVING  : 'AI_LEAVING',
};

const SPEC_PATH = path.resolve(__dirname, '../../specs/questions.spec.yaml');

class QuestionFlow {
  constructor() {
    const raw  = fs.readFileSync(SPEC_PATH, 'utf8');
    this.spec  = yaml.load(raw);
    this.qs    = this.spec.questions;    // array indexed 0..2
    this._silenceCount = {};             // { stateId: count }
  }

  // ── Current prompt ────────────────────────────────────────
  currentPrompt(state, answers, meta) {
    switch (state) {
      case STATE.GREETING:
        return this.spec.greeting.text;
      case STATE.QUESTION_1:
        return this._fillTemplate(this.qs[0].text, meta);
      case STATE.QUESTION_2:
        return this._fillTemplate(this.qs[1].text, meta);
      case STATE.QUESTION_3:
        return this._fillTemplate(this.qs[2].text, meta);
      default:
        return null;
    }
  }

  repromptText(state) {
    const qIdx = this._stateToIndex(state);
    if (qIdx < 0) return null;
    return this.qs[qIdx].re_prompt;
  }

  handoffText()     { return this.spec.handoff.text; }
  disqualifyText()  { return this.spec.disqualify.text; }

  // ── Intent classification ─────────────────────────────────
  // Simple keyword map — swap for an LLM classifier in production
  classify(transcript, state) {
    const t   = transcript.toLowerCase().trim();
    const map = this.spec.intent_map;
    for (const [intent, keywords] of Object.entries(map)) {
      if (keywords.some(kw => t.includes(kw))) return intent;
    }
    return 'unknown';
  }

  // ── Intent → state transition ─────────────────────────────
  processIntent(intent, state, answers) {
    const qIdx = this._stateToIndex(state);

    // If we're still in greeting, any intent moves to Q1
    if (state === STATE.GREETING) {
      return { nextState: STATE.QUESTION_1 };
    }

    if (qIdx < 0) return {};

    const q = this.qs[qIdx];

    // Record answer
    answers[q.capture_field] = intent;

    // Check disqualification
    if (q.disqualify_on && q.disqualify_on.includes(intent)) {
      if (q.disqualify_action === 'polite_hangup') {
        return { disqualify: true };
      }
      // disqualify_action === 'transfer_anyway' → fall through
    }

    // Advance to next state
    const nextState = this._nextState(state);
    this._silenceCount[state] = 0;
    return { nextState };
  }

  // ── Silence handling ──────────────────────────────────────
  onSilence(state) {
    if (!this._silenceCount[state]) this._silenceCount[state] = 0;
    this._silenceCount[state]++;

    const maxRetries = this.spec.timeouts.max_retries_per_question;

    if (this._silenceCount[state] <= maxRetries) {
      return { reprompt: true };
    }
    return { transferAnyway: true };
  }

  // ── Helpers ───────────────────────────────────────────────
  _stateToIndex(state) {
    return { QUESTION_1: 0, QUESTION_2: 1, QUESTION_3: 2 }[state] ?? -1;
  }

  _nextState(state) {
    return {
      GREETING   : STATE.QUESTION_1,
      QUESTION_1 : STATE.QUESTION_2,
      QUESTION_2 : STATE.QUESTION_3,
      QUESTION_3 : STATE.TRANSFERRING,
    }[state] || STATE.TRANSFERRING;
  }

  _fillTemplate(text, meta) {
    return text.replace(/\{lead_address\}/g, meta.address || 'your registered address');
  }
}

module.exports = QuestionFlow;
