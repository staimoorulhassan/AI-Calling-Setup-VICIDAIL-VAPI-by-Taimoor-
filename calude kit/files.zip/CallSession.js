'use strict';
/**
 * src/session/CallSession.js
 *
 * Owns one active call end-to-end:
 *   GREETING → Q1 → Q2 → Q3 → TRANSFERRING → AI_LEAVING
 *
 * Spec: specs/call-flow.spec.yaml → states
 */

const QuestionFlow      = require('./QuestionFlow');
const MossTTS           = require('../tts/MossTTS');
const STTClient         = require('../stt/STTClient');
const ThreeWayTransfer  = require('../transfer/ThreeWayTransfer');
const logger            = require('../utils/logger');

const STATE = {
  GREETING     : 'GREETING',
  QUESTION_1   : 'QUESTION_1',
  QUESTION_2   : 'QUESTION_2',
  QUESTION_3   : 'QUESTION_3',
  TRANSFERRING : 'TRANSFERRING',
  AI_LEAVING   : 'AI_LEAVING',
  COMPLETE     : 'COMPLETE',
};

class CallSession {
  constructor(ws, metadata) {
    this.ws       = ws;
    this.meta     = metadata;
    this.state    = STATE.GREETING;
    this.answers  = {};
    this.flow     = new QuestionFlow();
    this.stt      = new STTClient();
    this.transfer = new ThreeWayTransfer();
    this._destroyed = false;
  }

  // ── Lifecycle ────────────────────────────────────────────
  async start() {
    logger.info({ event: 'session_start', channel: this.meta.channel });
    this.stt.on('transcript', (text) => this._onTranscript(text));
    this.stt.on('silence',    ()     => this._onSilence());
    this.stt.start();
    await this._playAndAdvance();
  }

  onAudioFrame(buffer) {
    if (this._destroyed) return;
    this.stt.feed(buffer);
  }

  onControlMessage(msg) {
    logger.debug({ event: 'control_msg', msg });
  }

  destroy() {
    if (this._destroyed) return;
    this._destroyed = true;
    this.stt.stop();
    logger.info({ event: 'session_destroyed', channel: this.meta.channel });
  }

  // ── Audio helpers ─────────────────────────────────────────
  async _play(text) {
    try {
      const audio = await MossTTS.synthesise(text);
      if (!this._destroyed && this.ws.readyState === 1 /* OPEN */) {
        this.ws.send(audio);
      }
    } catch (err) {
      logger.error({ event: 'tts_error', error: err.message });
    }
  }

  // ── State machine ─────────────────────────────────────────
  async _playAndAdvance() {
    if (this._destroyed) return;

    const prompt = this.flow.currentPrompt(this.state, this.answers, this.meta);
    if (prompt) {
      await this._play(prompt);
    }

    if (this.state === STATE.TRANSFERRING || this.state === STATE.AI_LEAVING) {
      await this._doTransfer();
    }
  }

  async _onTranscript(text) {
    if (this._destroyed) return;
    logger.info({ event: 'transcript', state: this.state, text });

    const intent  = this.flow.classify(text, this.state);
    const advance = this.flow.processIntent(intent, this.state, this.answers);

    if (advance.disqualify) {
      await this._play(this.flow.disqualifyText());
      this._hangup();
      return;
    }

    if (advance.nextState) {
      this.state = advance.nextState;
    }

    await this._playAndAdvance();
  }

  async _onSilence() {
    if (this._destroyed) return;
    const result = this.flow.onSilence(this.state);

    if (result.reprompt) {
      const repromptText = this.flow.repromptText(this.state);
      await this._play(repromptText);
    } else if (result.transferAnyway) {
      logger.warn({ event: 'timeout_transfer_anyway', state: this.state });
      this.state = STATE.TRANSFERRING;
      await this._doTransfer();
    }
  }

  // ── Transfer logic ────────────────────────────────────────
  async _doTransfer() {
    this.state = STATE.TRANSFERRING;

    // Play handoff text first
    const handoff = this.flow.handoffText();
    await this._play(handoff);

    logger.info({ event: 'initiating_3way_transfer', channel: this.meta.channel });

    try {
      const result = await this.transfer.execute({
        leadChannel    : this.meta.channel,
        verifierNumber : process.env.VERIFIER_EXTENSION,
        callMetadata   : {
          leadId     : this.meta.leadId,
          answers    : this.answers,
          campaignId : this.meta.campaignId,
        },
      });

      logger.info({ event: 'transfer_complete', result });
      this.state = STATE.AI_LEAVING;

      // AI leg drops — AGI bridge will receive WS close and hangup
      this._hangup();

    } catch (err) {
      logger.error({ event: 'transfer_failed', error: err.message });
      this._hangup();
    }
  }

  _hangup() {
    if (this._destroyed) return;
    try {
      this.ws.send(JSON.stringify({ type: 'HANGUP' }));
      this.ws.close();
    } catch (_) {}
    this.destroy();
  }
}

module.exports = CallSession;
