# AI Outbound Lead Gen — VICIdial + MOSS-TTS + AVR
### Spec-driven kit (specify-plus@1.0)

---

## Architecture

```
VICIdial Campaign
  │  auto-dials from hopper
  ↓
AMD Detection  ──VM──→  skip / hang up
  │  human detected
  ↓
Asterisk EAGI Script (agi/ai-bridge.agi)
  │  opens WebSocket to AI agent
  ↓
AI Agent Server (src/server.js)           ← one CallSession per call
  ├─ MOSS-TTS    synthesises questions
  ├─ STT Client  streams audio → transcript
  └─ QuestionFlow  Q1 → Q2 → Q3 state machine
  │  all 3 answered
  ↓
ThreeWayTransfer (Asterisk AMI)
  ├─ Originate call to verifier
  ├─ Redirect lead into ConfBridge room
  └─ Drop AI agent leg
  ↓
VICIdial manages remainder
(verifier + lead in active bridge)
```

---

## Specs (specify-plus)

| File | What it governs |
|------|----------------|
| `specs/system.spec.yaml`    | Master spec — all components, data flow, env vars |
| `specs/call-flow.spec.yaml` | VICIdial campaign, dialplan, AGI bridge, state machine |
| `specs/questions.spec.yaml` | **Edit this** — 3 questions, intents, timeouts |
| `specs/moss-tts.spec.yaml`  | TTS voice, caching, error handling |
| `specs/transfer.spec.yaml`  | AMI sequence, conference settings |

---

## Quickstart

### 1. Prerequisites

- VICIdial server with Asterisk (AMD enabled on campaign)
- MOSS-TTS running (`docker-compose up moss-tts`)
- Deepgram API key (or local Whisper)
- Node.js 18+

### 2. Install

```bash
git clone <this-repo>
cd ai-lead-gen
npm install
cp .env.example .env
# Edit .env with your values
```

### 3. Configure questions

Edit `specs/questions.spec.yaml` — change the question `text`, `re_prompt`, and `intent_map` to match your campaign script.

### 4. Asterisk dialplan

Add the `[ai-lead-gen]` context to your Asterisk `extensions.conf`:

```bash
# On your VICIdial/Asterisk server:
cp config/extensions.conf /etc/asterisk/ai-lead-gen.conf
# Add to /etc/asterisk/extensions.conf:
#   #include ai-lead-gen.conf
asterisk -rx "dialplan reload"
```

### 5. VICIdial campaign settings

In VICIdial admin → Campaigns → [your campaign]:
- **AMD** → Enabled
- **AMD action on HUMAN** → `local/ai-agent@ai-lead-gen`
- **AMD action on MACHINE** → `HANGUP` (or voicemail)

### 6. Deploy AI agent

```bash
# Option A: direct
node src/server.js

# Option B: Docker (MOSS-TTS + AI agent together)
docker-compose up -d
```

### 7. Place the AGI script on Asterisk

```bash
cp agi/ai-bridge.agi /var/lib/asterisk/agi-bin/
chmod +x /var/lib/asterisk/agi-bin/ai-bridge.agi
npm install ws  # on Asterisk server, for the AGI script
```

---

## Customising Questions

All question logic lives in `specs/questions.spec.yaml`. Change the text, re-prompts, intent triggers, and disqualification rules there — **no code changes needed**.

The `QuestionFlow` class reads the spec at startup and caches TTS audio for every prompt.

---

## AgentVoiceResponse repos

This kit is designed to be combined with https://github.com/agentvoiceresponse:

- `avr-asterisk` — replace `agi/ai-bridge.agi` with AVR's Asterisk connector
- `avr-openai` — replace the keyword `intent_map` with GPT-4o for intent classification
- `avr-core` — can host the WebSocket server instead of `src/server.js`

The `CallSession` class maps 1:1 to an AVR session. Swap the internals; the state machine and spec layer stay the same.

---

## Directory layout

```
ai-lead-gen/
├── specs/
│   ├── system.spec.yaml       ← master spec
│   ├── call-flow.spec.yaml    ← VICIdial + AGI bridge
│   ├── questions.spec.yaml    ← EDIT: your 3 questions
│   ├── moss-tts.spec.yaml     ← TTS settings
│   └── transfer.spec.yaml     ← AMI transfer sequence
├── agi/
│   └── ai-bridge.agi          ← EAGI script (Node.js)
├── src/
│   ├── server.js              ← WS server, one session per call
│   ├── session/
│   │   ├── CallSession.js     ← state machine
│   │   └── QuestionFlow.js    ← loads questions.spec, drives flow
│   ├── tts/
│   │   └── MossTTS.js         ← MOSS-TTS HTTP client + LRU cache
│   ├── stt/
│   │   └── STTClient.js       ← Deepgram / Whisper streaming
│   ├── transfer/
│   │   └── ThreeWayTransfer.js← AMI originate + redirect + hangup
│   ├── ami/
│   │   └── AsteriskAMI.js     ← TCP AMI client singleton
│   └── utils/
│       └── logger.js
├── config/
│   └── extensions.conf        ← Asterisk dialplan context
├── .env.example
├── docker-compose.yml
└── package.json
```
