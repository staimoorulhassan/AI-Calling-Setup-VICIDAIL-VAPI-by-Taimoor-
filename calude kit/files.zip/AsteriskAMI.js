'use strict';
/**
 * src/ami/AsteriskAMI.js
 *
 * Thin Asterisk Manager Interface (AMI) client.
 * Maintains a persistent TCP connection to Asterisk.
 * Exposes action() for sending AMI commands and
 * on(event) for subscribing to AMI events.
 *
 * Spec: specs/transfer.spec.yaml → ami
 */

const net          = require('net');
const EventEmitter = require('events');
const logger       = require('../utils/logger');

const HOST           = process.env.ASTERISK_HOST     || '127.0.0.1';
const PORT           = parseInt(process.env.ASTERISK_AMI_PORT || '5038', 10);
const USERNAME       = process.env.ASTERISK_AMI_USER   || 'admin';
const SECRET         = process.env.ASTERISK_AMI_SECRET || 'amp111';
const RECONNECT_MS   = 3000;
const PING_MS        = 10000;

class AsteriskAMI extends EventEmitter {
  constructor() {
    super();
    this._socket        = null;
    this._buf           = '';
    this._pendingActions= new Map();  // actionId → { resolve, reject, timer }
    this._authenticated = false;
    this._reconnectT    = null;
    this._pingT         = null;
    this._actionSeq     = 1;
  }

  connect() {
    return new Promise((resolve, reject) => {
      this._socket = new net.Socket();
      this._socket.setEncoding('utf8');

      this._socket.connect(PORT, HOST, () => {
        logger.info({ event: 'ami_connected', host: HOST, port: PORT });
      });

      this._socket.on('data', (chunk) => this._onData(chunk));

      this._socket.on('close', () => {
        logger.warn({ event: 'ami_disconnected' });
        this._authenticated = false;
        clearInterval(this._pingT);
        this._scheduleReconnect();
      });

      this._socket.on('error', (err) => {
        logger.error({ event: 'ami_socket_error', error: err.message });
        if (!this._authenticated) reject(err);
      });

      this.once('authenticated', () => {
        this._startPing();
        resolve();
      });
    });
  }

  /**
   * Send an AMI action. Returns a Promise resolving to the response event.
   */
  action(name, params = {}, timeoutMs = 10000) {
    return new Promise((resolve, reject) => {
      const actionId = `avr-${this._actionSeq++}`;
      const lines    = [`Action: ${name}`, `ActionID: ${actionId}`];

      for (const [k, v] of Object.entries(params)) {
        lines.push(`${k}: ${v}`);
      }
      lines.push('\r\n');

      const timer = setTimeout(() => {
        this._pendingActions.delete(actionId);
        reject(new Error(`AMI action ${name} timed out`));
      }, timeoutMs);

      this._pendingActions.set(actionId, { resolve, reject, timer });
      this._socket.write(lines.join('\r\n') + '\r\n');
    });
  }

  // ── Data parsing ──────────────────────────────────────────
  _onData(chunk) {
    this._buf += chunk;
    const blocks = this._buf.split('\r\n\r\n');
    this._buf    = blocks.pop();  // keep incomplete block

    for (const block of blocks) {
      if (!block.trim()) continue;
      const msg = this._parseBlock(block);
      this._dispatch(msg);
    }
  }

  _parseBlock(block) {
    const obj = {};
    for (const line of block.split('\r\n')) {
      const idx = line.indexOf(':');
      if (idx < 0) continue;
      const key = line.slice(0, idx).trim();
      const val = line.slice(idx + 1).trim();
      obj[key]  = val;
    }
    return obj;
  }

  _dispatch(msg) {
    // Login challenge / success
    if (msg.Response === 'Success' && msg.Message === 'Authentication accepted') {
      this._authenticated = true;
      this.emit('authenticated');
    }

    // Resolve pending action
    if (msg.ActionID && this._pendingActions.has(msg.ActionID)) {
      const { resolve, timer } = this._pendingActions.get(msg.ActionID);
      clearTimeout(timer);
      this._pendingActions.delete(msg.ActionID);
      resolve(msg);
    }

    // Emit named AMI event
    if (msg.Event) this.emit(msg.Event, msg);

    this.emit('*', msg);
  }

  // ── Auth ──────────────────────────────────────────────────
  _login() {
    const payload = [
      'Action: Login',
      `Username: ${USERNAME}`,
      `Secret: ${SECRET}`,
      '\r\n',
    ].join('\r\n') + '\r\n';
    this._socket.write(payload);
  }

  _startPing() {
    this._pingT = setInterval(() => {
      this.action('Ping').catch(() => {});
    }, PING_MS);
  }

  _scheduleReconnect() {
    if (this._reconnectT) return;
    this._reconnectT = setTimeout(() => {
      this._reconnectT = null;
      logger.info({ event: 'ami_reconnecting' });
      this.connect().catch(err => logger.error({ event: 'ami_reconnect_failed', error: err.message }));
    }, RECONNECT_MS);
  }
}

// ── Singleton ─────────────────────────────────────────────
const ami = new AsteriskAMI();

// Auto-connect on first require
ami.connect().catch(err => {
  logger.error({ event: 'ami_initial_connect_failed', error: err.message });
});

module.exports = ami;
