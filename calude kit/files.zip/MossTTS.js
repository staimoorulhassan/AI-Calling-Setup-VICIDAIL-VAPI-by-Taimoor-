'use strict';
/**
 * src/tts/MossTTS.js
 *
 * HTTP client for the MOSS-TTS local server.
 * Returns raw ulaw audio Buffer ready to send over WebSocket.
 *
 * Spec: specs/moss-tts.spec.yaml
 */

const http    = require('http');
const https   = require('https');
const crypto  = require('crypto');
const fs      = require('fs');
const path    = require('path');
const yaml    = require('js-yaml');
const logger  = require('../utils/logger');

const SPEC_PATH = path.resolve(__dirname, '../../specs/moss-tts.spec.yaml');
const Q_SPEC    = path.resolve(__dirname, '../../specs/questions.spec.yaml');

const spec     = yaml.load(fs.readFileSync(SPEC_PATH, 'utf8'));
const qSpec    = yaml.load(fs.readFileSync(Q_SPEC,   'utf8'));

const BASE_URL = process.env.MOSS_TTS_URL || 'http://localhost:5002';
const ENDPOINT = spec.server.endpoint_synthesise;  // /api/tts

// ── LRU Cache ─────────────────────────────────────────────
class LRUCache {
  constructor(max = 100) {
    this.max  = max;
    this.map  = new Map();
  }
  get(key) {
    if (!this.map.has(key)) return null;
    const val = this.map.get(key);
    this.map.delete(key);
    this.map.set(key, val);
    return val;
  }
  set(key, val) {
    if (this.map.has(key)) this.map.delete(key);
    else if (this.map.size >= this.max) this.map.delete(this.map.keys().next().value);
    this.map.set(key, val);
  }
}

const cache = new LRUCache(spec.cache.max_entries);

// ── Fallback audio (short silence ulaw buffer) ────────────
const FALLBACK_AUDIO = Buffer.alloc(160, 0xFF);  // 20ms of ulaw silence

// ── Cache key ─────────────────────────────────────────────
function cacheKey(text) {
  return crypto.createHash('sha256')
    .update(text + spec.synthesis.voice + spec.synthesis.sample_rate)
    .digest('hex');
}

// ── HTTP POST to MOSS-TTS ─────────────────────────────────
function httpPost(url, body) {
  return new Promise((resolve, reject) => {
    const parsed  = new URL(url);
    const mod     = parsed.protocol === 'https:' ? https : http;
    const payload = JSON.stringify(body);

    const req = mod.request({
      hostname : parsed.hostname,
      port     : parsed.port || (parsed.protocol === 'https:' ? 443 : 80),
      path     : parsed.pathname,
      method   : 'POST',
      headers  : { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) },
    }, (res) => {
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end',  () => {
        if (res.statusCode !== 200) return reject(new Error(`TTS HTTP ${res.statusCode}`));
        resolve(Buffer.concat(chunks));
      });
    });

    req.setTimeout(8000, () => { req.destroy(); reject(new Error('TTS_TIMEOUT')); });
    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}

// ── Public API ────────────────────────────────────────────
const MossTTS = {

  /**
   * Synthesise text → ulaw audio Buffer.
   * Checks LRU cache first; falls back to silence on error.
   */
  async synthesise(text) {
    if (!text) return FALLBACK_AUDIO;

    const key    = cacheKey(text);
    const cached = cache.get(key);
    if (cached) return cached;

    try {
      const body  = {
        text,
        voice          : spec.synthesis.voice,
        output_format  : spec.synthesis.output_format,
        sample_rate    : spec.synthesis.sample_rate,
        speaking_rate  : spec.synthesis.speaking_rate,
        pitch          : spec.synthesis.pitch,
      };
      const audio = await httpPost(`${BASE_URL}${ENDPOINT}`, body);
      cache.set(key, audio);
      return audio;
    } catch (err) {
      logger.error({ event: 'tts_error', error: err.message, text: text.slice(0, 60) });
      return FALLBACK_AUDIO;
    }
  },

  /**
   * Pre-warm cache with all static question prompts.
   * Called once at server startup.
   */
  async prewarm() {
    if (!spec.cache.pre_warm_on_start) return;

    const texts = [
      qSpec.greeting.text,
      ...qSpec.questions.map(q => q.text),
      ...qSpec.questions.map(q => q.re_prompt),
      qSpec.handoff.text,
      qSpec.disqualify.text,
    ].filter(Boolean);

    logger.info(`Pre-warming TTS cache with ${texts.length} entries...`);

    await Promise.allSettled(texts.map(t => this.synthesise(t)));
    logger.info('TTS cache pre-warm complete');
  },
};

module.exports = MossTTS;
