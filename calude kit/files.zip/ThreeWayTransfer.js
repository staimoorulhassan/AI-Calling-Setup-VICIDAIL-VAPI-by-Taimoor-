'use strict';
/**
 * src/transfer/ThreeWayTransfer.js
 *
 * Executes the 5-step AMI sequence defined in transfer.spec.yaml:
 *   1. Originate call to verifier
 *   2. Move lead into conference bridge
 *   3. Wait for verifier to join
 *   4. Drop the AI agent leg
 *
 * Spec: specs/transfer.spec.yaml → sequence
 */

const { v4: uuidv4 } = require('uuid');
const ami    = require('../ami/AsteriskAMI');
const logger = require('../utils/logger');

const CONF_PREFIX   = process.env.CONFERENCE_ROOM_PREFIX || 'leadgen';
const CONTEXT       = 'ai-lead-gen';
const BRIDGE_TIMEOUT= 35000;   // 35s for verifier to answer

class ThreeWayTransfer {

  /**
   * Execute the full 3-way transfer.
   *
   * @param {object} params
   * @param {string} params.leadChannel      - Asterisk channel for the lead leg
   * @param {string} params.verifierNumber   - Extension or DID to dial
   * @param {object} params.callMetadata     - { leadId, answers, campaignId }
   *
   * @returns {Promise<{ conferenceId, verifierChannel, status }>}
   */
  async execute({ leadChannel, verifierNumber, callMetadata }) {
    const confId    = `${CONF_PREFIX}-${uuidv4().slice(0, 8)}`;
    logger.info({ event: 'transfer_start', leadChannel, verifierNumber, confId });

    // ── Step 1: Originate call to verifier ───────────────────
    logger.info({ event: 'ami_originate_verifier', verifierNumber });
    let originateResult;
    try {
      originateResult = await ami.action('Originate', {
        Channel  : `SIP/${verifierNumber}`,
        Context  : CONTEXT,
        Exten    : 'conference-verifier',
        Priority : 1,
        Variable : `CONF_ID=${confId}`,
        Async    : 'true',
        Timeout  : 30000,
        Account  : callMetadata.leadId || '',
      }, BRIDGE_TIMEOUT);
    } catch (err) {
      logger.error({ event: 'originate_failed', error: err.message });
      throw new Error('ORIGINATE_FAILED');
    }

    if (originateResult.Response !== 'Success') {
      throw new Error(`AMI Originate rejected: ${originateResult.Message}`);
    }

    // ── Step 2: Move lead into conference ────────────────────
    logger.info({ event: 'ami_redirect_lead', leadChannel, confId });
    try {
      await ami.action('Redirect', {
        Channel  : leadChannel,
        Context  : CONTEXT,
        Exten    : 'conference-verifier',
        Priority : 1,
        ExtraChannel: '',
        ExtraContext: '',
        ExtraExten  : '',
        ExtraPriority: 1,
      });
    } catch (err) {
      logger.warn({ event: 'redirect_warning', error: err.message });
      // Non-fatal — lead may already be in the bridge
    }

    // ── Step 3: Wait for verifier to join ────────────────────
    const verifierChannel = await this._waitForVerifierJoin(confId);

    // ── Step 4: Post metadata to VICIdial callback (optional) ─
    this._notifyVicidial(confId, callMetadata).catch(() => {});

    logger.info({ event: 'transfer_success', confId, verifierChannel });
    return { conferenceId: confId, verifierChannel, status: 'success' };
  }

  // ── Helpers ───────────────────────────────────────────────

  /**
   * Wait for a ConfbridgeJoin AMI event for our conference room.
   */
  _waitForVerifierJoin(confId, timeoutMs = 8000) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        ami.off('ConfbridgeJoin', listener);
        logger.warn({ event: 'verifier_join_timeout', confId });
        // Resolve anyway — lead + verifier may still be bridged
        resolve('unknown');
      }, timeoutMs);

      const listener = (event) => {
        if (event.Conference === confId) {
          clearTimeout(timer);
          ami.off('ConfbridgeJoin', listener);
          logger.info({ event: 'verifier_joined', confId, channel: event.Channel });
          resolve(event.Channel);
        }
      };

      ami.on('ConfbridgeJoin', listener);
    });
  }

  /**
   * Optional: POST answer data back to VICIdial / CRM webhook.
   */
  async _notifyVicidial(confId, metadata) {
    const webhookUrl = process.env.VICIDIAL_CALLBACK_URL;
    if (!webhookUrl) return;

    const fetch = (await import('node-fetch')).default;
    await fetch(webhookUrl, {
      method  : 'POST',
      headers : { 'Content-Type': 'application/json' },
      body    : JSON.stringify({ confId, ...metadata, timestamp: new Date().toISOString() }),
    });
    logger.info({ event: 'vicidial_notified', confId });
  }
}

module.exports = ThreeWayTransfer;
