'use strict';
/**
 * src/server.js — AI Agent WebSocket Server
 *
 * Each inbound WS connection = one active call.
 * Spawns a CallSession that owns the question flow,
 * TTS playback, STT listening and 3-way transfer.
 *
 * Spec: specs/ai-agent.spec.yaml
 */

const { WebSocketServer } = require('ws');
const http                = require('http');
const CallSession         = require('./session/CallSession');
const MossTTS             = require('./tts/MossTTS');
const logger              = require('./utils/logger');

const PORT       = parseInt(process.env.AI_AGENT_WS_PORT || '8080', 10);
const httpServer = http.createServer((req, res) => {
  res.writeHead(200);
  res.end('AI Agent running\n');
});

const wss = new WebSocketServer({ server: httpServer, path: '/call' });

// Pre-warm TTS cache at startup (questions.spec.yaml → cache.pre_warm_on_start)
MossTTS.prewarm().then(() => logger.info('TTS cache pre-warmed'));

wss.on('connection', (ws, req) => {
  let metadata = {};
  try {
    metadata = JSON.parse(req.headers['x-call-metadata'] || '{}');
  } catch (_) {}

  logger.info({ event: 'call_connected', ...metadata });

  const session = new CallSession(ws, metadata);
  session.start();

  ws.on('message', (data) => {
    // Binary = audio frame from Asterisk (ulaw)
    if (data instanceof Buffer) session.onAudioFrame(data);
    // String = JSON control message
    else {
      try { session.onControlMessage(JSON.parse(data)); }
      catch (_) {}
    }
  });

  ws.on('close', () => {
    logger.info({ event: 'call_disconnected', channel: metadata.channel });
    session.destroy();
  });

  ws.on('error', (err) => {
    logger.error({ event: 'ws_error', error: err.message });
    session.destroy();
  });
});

httpServer.listen(PORT, () => {
  logger.info(`AI Agent WS server listening on :${PORT}`);
});

// ── Graceful shutdown ─────────────────────────────────────
process.on('SIGTERM', () => {
  logger.info('SIGTERM — closing server');
  wss.close(() => { httpServer.close(() => process.exit(0)); });
});
