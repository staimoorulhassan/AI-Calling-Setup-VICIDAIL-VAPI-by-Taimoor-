# ============================================================
# .env — Vapi edition
# Replaces: MOSS_TTS_URL, STT_PROVIDER, STT_API_KEY
# ============================================================

# ── Vapi (replaces MOSS-TTS + STT + WebSocket AI agent) ──────
VAPI_API_KEY=7f934503-2faa-48ca-b46b-ade35a66b77c
VAPI_ASSISTANT_ID=bec20f66-2bc6-41fc-856f-c51779736e87
VAPI_PHONE_NUMBER_ID=<uuid-from-vapi-dashboard>
VAPI_PHONE_NUMBER=+14155550100          # E.164, Vapi-provisioned
VAPI_WEBHOOK_SECRET=<random-secret>     # optional HMAC validation

# ── Webhook server (NEW — receives Vapi call events) ─────────
VAPI_WEBHOOK_PORT=3001
VAPI_WEBHOOK_URL=https://your-server.example.com   # public URL

# ── VICIdial / Asterisk ───────────────────────────────────────
ASTERISK_HOST=127.0.0.1
ASTERISK_AMI_PORT=5038
ASTERISK_AMI_USER=admin
ASTERISK_AMI_SECRET=amp111
VERIFIER_EXTENSION=8500

# ── VICIdial results callback ─────────────────────────────────
VICIDIAL_CALLBACK_URL=http://your-vicidial-host/vicidial/non_agent_api.php

# ── Logging ───────────────────────────────────────────────────
LOG_LEVEL=info

# ── REMOVED (no longer needed) ───────────────────────────────
# MOSS_TTS_URL         → Vapi has built-in TTS
# STT_PROVIDER         → Vapi has built-in STT
# STT_API_KEY          → Vapi has built-in STT
# AI_AGENT_WS_PORT     → no custom WebSocket server
# AGI_WS_BRIDGE_URL    → no AGI WebSocket bridge
# OPENAI_API_KEY       → configure model inside Vapi assistant
# QUESTION_TIMEOUT_MS  → configure endpointing in Vapi assistant
# MAX_RETRIES_PER_Q    → configure in Vapi assistant prompt
