'use strict';
/**
 * src/vapi/VapiWebhookServer.js
 *
 * Express HTTP server that receives events Vapi POSTs to your
 * public URL.  Channel ③ in the architecture.
 *
 * Configure in Vapi dashboard (or via API PATCH /assistant):
 *   serverUrl: "https://your-server.example.com/vapi/webhook"
 *
 * Events handled:
 *   call.started   → log call, store lead mapping
 *   transcript     → log partial / final utterances
 *   function-call  → handle any custom tool the assistant calls
 *   call.ended     → save transcript + answers, notify VICIdial
 *
 * Spec: specs/vapi-integration.spec.yaml → channel 3_webhooks
 */

const http    = require('http');
const crypto  = require('crypto');
const VapiCallHandler = require('./VapiCallHandler');
const logger  = require('../utils/logger');

const PORT           = parseInt(process.env.VAPI_WEBHOOK_PORT || '3001', 10);
const WEBHOOK_SECRET = process.env.VAPI_WEBHOOK_SECRET || '';

// ── Signature validation (optional but recommended) ───────────
function verifySignature(rawBody, signatureHeader) {
  if (!WEBHOOK_SECRET) return true;   // skip if secret not configured
  if (!signatureHeader) return false;

  const expected = crypto
    .createHmac('sha256', WEBHOOK_SECRET)
    .update(rawBody)
    .digest('hex');

  return crypto.timingSafeEqual(
    Buffer.from(signatureHeader, 'hex'),
    Buffer.from(expected, 'hex')
  );
}

// ── Raw body collector ────────────────────────────────────────
function collectBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end',  () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

// ── Request router ────────────────────────────────────────────
async function handleRequest(req, res) {
  if (req.method === 'GET' && req.url === '/health') {
    res.writeHead(200);
    return res.end('OK\n');
  }

  if (req.method !== 'POST' || req.url !== '/vapi/webhook') {
    res.writeHead(404);
    return res.end('Not found\n');
  }

  const rawBody = await collectBody(req);
  const sig     = req.headers['x-vapi-signature'] || '';

  if (!verifySignature(rawBody, sig)) {
    logger.warn({ event: 'vapi_webhook_bad_sig', sig });
    res.writeHead(401);
    return res.end('Invalid signature\n');
  }

  let event;
  try {
    event = JSON.parse(rawBody.toString('utf8'));
  } catch (_) {
    res.writeHead(400);
    return res.end('Bad JSON\n');
  }

  logger.debug({ event: 'vapi_webhook_received', type: event.message?.type || event.type });

  // Vapi wraps payload in { message: { type, ... } } in newer SDK versions
  const payload = event.message || event;

  try {
    await dispatch(payload, res);
  } catch (err) {
    logger.error({ event: 'vapi_webhook_handler_error', error: err.message });
    if (!res.headersSent) {
      res.writeHead(500);
      res.end('Internal error\n');
    }
  }
}

// ── Event dispatcher ──────────────────────────────────────────
async function dispatch(payload, res) {
  const type = payload.type;

  switch (type) {

    case 'call.started':
      await VapiCallHandler.onCallStarted(payload);
      break;

    case 'transcript':
      await VapiCallHandler.onTranscript(payload);
      break;

    case 'function-call':
    case 'tool-calls':
      // Return a JSON result — Vapi waits for this response
      const result = await VapiCallHandler.onFunctionCall(payload);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ result }));

    case 'call.ended':
      await VapiCallHandler.onCallEnded(payload);
      break;

    case 'assistant-request':
      // Dynamic assistant selection (optional override)
      res.writeHead(200, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({
        assistantId: process.env.VAPI_ASSISTANT_ID,
      }));

    default:
      logger.warn({ event: 'vapi_webhook_unknown_type', type });
  }

  res.writeHead(200);
  res.end('OK\n');
}

// ── Server lifecycle ──────────────────────────────────────────
const server = http.createServer((req, res) => {
  handleRequest(req, res).catch(err => {
    logger.error({ event: 'vapi_webhook_unhandled', error: err.message });
    if (!res.headersSent) { res.writeHead(500); res.end(); }
  });
});

server.listen(PORT, () => {
  logger.info({ event: 'vapi_webhook_server_ready', port: PORT });
});

process.on('SIGTERM', () => {
  server.close(() => process.exit(0));
});

module.exports = server;
