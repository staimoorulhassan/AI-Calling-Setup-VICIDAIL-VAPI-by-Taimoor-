'use strict';
/**
 * src/vapi/VapiCallHandler.js
 *
 * Processes every Vapi webhook event.
 * Owns the business logic that was previously in CallSession:
 *   - recording which questions were answered and with what
 *   - notifying VICIdial when the call is complete
 *   - handling any custom function-call tools
 *
 * Spec: specs/vapi-integration.spec.yaml → channels[3_webhooks]
 */

const http   = require('http');
const https  = require('https');
const logger = require('../utils/logger');

// In-memory call state (swap for Redis in multi-instance deploys)
const callMap = new Map();   // callId → { leadId, answers, startedAt }

// ── Helpers ───────────────────────────────────────────────────
function notifyVicidial(callId, data) {
  const url = process.env.VICIDIAL_CALLBACK_URL;
  if (!url) return Promise.resolve();

  const payload = JSON.stringify({ callId, timestamp: new Date().toISOString(), ...data });
  const parsed  = new URL(url);
  const mod     = parsed.protocol === 'https:' ? https : http;

  return new Promise((resolve) => {
    const req = mod.request({
      hostname : parsed.hostname,
      port     : parsed.port || (parsed.protocol === 'https:' ? 443 : 80),
      path     : parsed.pathname + parsed.search,
      method   : 'POST',
      headers  : { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) },
    }, (res) => {
      res.resume();
      logger.info({ event: 'vicidial_notified', callId, status: res.statusCode });
      resolve();
    });
    req.on('error', (err) => {
      logger.error({ event: 'vicidial_notify_error', error: err.message });
      resolve();
    });
    req.write(payload);
    req.end();
  });
}

// ── Handlers ──────────────────────────────────────────────────
const VapiCallHandler = {

  /**
   * call.started
   * Payload: { call: { id, phoneNumber, customer, metadata, ... } }
   */
  async onCallStarted(payload) {
    const call = payload.call || {};
    const id   = call.id;

    callMap.set(id, {
      leadPhone  : call.customer?.number || '',
      leadId     : call.metadata?.leadId || '',
      campaignId : call.metadata?.campaignId || '',
      answers    : {},
      startedAt  : Date.now(),
    });

    logger.info({ event: 'vapi_call_started', callId: id, leadPhone: callMap.get(id).leadPhone });
  },

  /**
   * transcript
   * Payload: { call: { id }, transcript: { role, text, isFinal } }
   * Fired for every utterance — both assistant and user sides.
   */
  async onTranscript(payload) {
    const callId = payload.call?.id;
    const t      = payload.transcript || {};

    logger.debug({ event: 'vapi_transcript', callId, role: t.role, text: t.text, final: t.isFinal });

    if (!t.isFinal || t.role !== 'user') return;

    const state = callMap.get(callId);
    if (!state) return;

    // Count answered questions (rough heuristic — refine with assistant metadata)
    const count = Object.keys(state.answers).length;
    if (count < 3) {
      state.answers[`Q${count + 1}`] = t.text;
      logger.info({ event: 'answer_captured', callId, question: `Q${count + 1}`, answer: t.text });
    }
  },

  /**
   * function-call / tool-calls
   * Called when the Vapi assistant invokes a custom tool.
   * Return value is sent back to the LLM as the tool result.
   */
  async onFunctionCall(payload) {
    const fn   = payload.functionCall || (payload.toolCallList || [])[0] || {};
    const name = fn.name || fn.function?.name || '';
    const args = fn.parameters || fn.function?.arguments || {};

    logger.info({ event: 'vapi_function_call', name, args });

    switch (name) {
      case 'lookupLeadData': {
        // Example: assistant asks for lead address to fill into Q3
        const callId = payload.call?.id;
        const state  = callMap.get(callId) || {};
        return { address: state.leadAddress || 'your registered address' };
      }

      default:
        logger.warn({ event: 'vapi_unknown_function', name });
        return { error: `Unknown function: ${name}` };
    }
  },

  /**
   * call.ended
   * Payload: { call: { id, endedReason, transcript, summary, ... } }
   * This fires after Vapi's transferCall completes and the AI leg drops.
   */
  async onCallEnded(payload) {
    const call   = payload.call || {};
    const callId = call.id;
    const state  = callMap.get(callId) || {};

    logger.info({
      event      : 'vapi_call_ended',
      callId,
      endedReason: call.endedReason,
      duration   : call.duration,
      answers    : state.answers,
    });

    // Post results back to VICIdial
    await notifyVicidial(callId, {
      leadId     : state.leadId,
      campaignId : state.campaignId,
      answers    : state.answers,
      transcript : call.transcript || [],
      endedReason: call.endedReason,
      duration   : call.duration,
    });

    callMap.delete(callId);
  },
};

module.exports = VapiCallHandler;
