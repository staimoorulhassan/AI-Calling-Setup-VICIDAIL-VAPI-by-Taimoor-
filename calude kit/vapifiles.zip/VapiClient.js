'use strict';
/**
 * src/vapi/VapiClient.js
 *
 * Thin REST client for api.vapi.ai.
 * All requests carry:   Authorization: Bearer {VAPI_API_KEY}
 *                       Content-Type: application/json
 *
 * Spec: specs/vapi-integration.spec.yaml → credentials + channels
 *
 * API key  → VAPI_API_KEY  env var (never hardcode)
 * Assistant → VAPI_ASSISTANT_ID env var
 */

const https  = require('https');
const logger = require('../utils/logger');

const BASE     = 'api.vapi.ai';
const API_KEY  = process.env.VAPI_API_KEY   || '';
const ASST_ID  = process.env.VAPI_ASSISTANT_ID || '';

if (!API_KEY) logger.warn({ event: 'vapi_no_api_key', msg: 'VAPI_API_KEY not set' });

// ── Generic HTTPS request helper ─────────────────────────────
function request(method, path, body, timeoutMs = 10000) {
  return new Promise((resolve, reject) => {
    const payload = body ? JSON.stringify(body) : null;
    const options = {
      hostname : BASE,
      port     : 443,
      path,
      method,
      headers  : {
        'Authorization' : `Bearer ${API_KEY}`,
        'Content-Type'  : 'application/json',
        ...(payload ? { 'Content-Length': Buffer.byteLength(payload) } : {}),
      },
    };

    const req = https.request(options, (res) => {
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => {
        const raw  = Buffer.concat(chunks).toString();
        const ok   = res.statusCode >= 200 && res.statusCode < 300;
        let parsed = {};
        try { parsed = JSON.parse(raw); } catch (_) { parsed = { raw }; }

        logger.debug({ event: 'vapi_response', status: res.statusCode, path });

        if (!ok) {
          return reject(Object.assign(
            new Error(`Vapi ${res.statusCode}: ${parsed.message || raw}`),
            { status: res.statusCode, body: parsed }
          ));
        }
        resolve(parsed);
      });
    });

    req.setTimeout(timeoutMs, () => { req.destroy(); reject(new Error('Vapi request timed out')); });
    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

// ── Public API ────────────────────────────────────────────────
const VapiClient = {

  /**
   * GET /assistant/:id
   * Verify the assistant exists and return its config.
   */
  getAssistant(assistantId = ASST_ID) {
    return request('GET', `/assistant/${assistantId}`);
  },

  /**
   * GET /call/:id
   * Fetch call details including transcript and status.
   */
  getCall(callId) {
    return request('GET', `/call/${callId}`);
  },

  /**
   * GET /call?limit=N
   * List recent calls (useful for debugging).
   */
  listCalls(limit = 10) {
    return request('GET', `/call?limit=${limit}`);
  },

  /**
   * DELETE /call/:id
   * End an active call programmatically (e.g. on error).
   */
  endCall(callId) {
    return request('DELETE', `/call/${callId}`);
  },

  /**
   * PATCH /call/:id
   * Update metadata on a live call (e.g. inject lead data).
   */
  updateCall(callId, patch) {
    return request('PATCH', `/call/${callId}`, patch);
  },

  /**
   * POST /call
   * Create an outbound call from Vapi directly.
   * Only needed if you want Vapi to initiate the call
   * rather than receiving a SIP transfer from VICIdial.
   *
   * @param {string} toNumber   Lead E.164 phone number
   * @param {string} fromNumber Vapi phone number (E.164)
   * @param {object} metadata   Passed through to webhooks
   */
  createOutboundCall(toNumber, fromNumber, metadata = {}) {
    return request('POST', '/call', {
      type         : 'outboundPhoneCall',
      assistantId  : ASST_ID,
      phoneNumberId: process.env.VAPI_PHONE_NUMBER_ID,
      customer     : { number: toNumber },
      phoneNumber  : { number: fromNumber },
      metadata,
    });
  },

  /**
   * Verify the API key and assistant are reachable.
   * Call this at server startup.
   */
  async healthCheck() {
    try {
      const asst = await this.getAssistant();
      logger.info({ event: 'vapi_health_ok', assistantName: asst.name, id: asst.id });
      return true;
    } catch (err) {
      logger.error({ event: 'vapi_health_fail', error: err.message });
      return false;
    }
  },
};

module.exports = VapiClient;
